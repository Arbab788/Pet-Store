package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class pet_doctors {
    public static String generate_doc_ID() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(doctor_id) from pet_doctors");
            int count = 0;


            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        }
        catch (Exception e) {
            System.out.println("generateProductID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void add_doctor(String doc_id, String fname, String lname, String fees) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into pet_doctors"
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, doc_id);
            preparedStmt.setString(2, fname);
            preparedStmt.setString(3, lname);
            preparedStmt.setString(4, fees);
//            System.out.println("inserted doctor");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("adddoctor() error;");
            System.out.println(e);
        }

    }

    public static String view_doctors() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from pet_doctors");
            ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }

    public static boolean search_doctors(String doc_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select doctor_id" +
                    " from pet_doctors where doctor_id = ?");
            queryStatement.setString(1, doc_id);
            ResultSet rs = queryStatement.executeQuery();
            if (rs.next()) {
                if (rs.getString(1).equals(doc_id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search_doc() error");
            System.out.println(e);
        }
        return false;
    }

    public static void update_doctor(String fname, String l_name, String fees, String doc_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE PET_DOCTORS "
                    + " SET FIRST_NAME = ?, LAST_NAME=? , FEES= ? "
                    + "WHERE doctor_ID = ?");
            queryStatement.setString(1, fname);
            queryStatement.setString(2, l_name);
            queryStatement.setString(3, fees);
            queryStatement.setString(4, doc_id);
            queryStatement.executeUpdate();
            System.out.println("updateddoctors");

        } catch (Exception e) {
            System.out.println("update_doctors() error");
            System.out.println(e);
        }

    }

    public static void delete_doctors(String doc_id) {
        Connection connection;

        try {
//            System.out.println("pet_id="+pet_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM PET_DOCTORS WHERE DOCTOR_ID = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, doc_id);
            ps1.executeUpdate();

            System.out.println(" DOCTOR deleted successfully");
        } catch (Exception e) {
            System.out.println("delete_doctors(); error");
            System.out.println(e);
        }

    }
    public static String docname(String doc_id){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select first_name" +
                    " from pet_doctors where doctor_id = ?");
            queryStatement.setString(1, doc_id);
            ResultSet rs = queryStatement.executeQuery();
            if (rs.next()) {
                return rs.getString(1);
            }

        } catch (Exception e) {
            System.out.println("search_doc() error");
            System.out.println(e);
        }
        return null;
    }

}
