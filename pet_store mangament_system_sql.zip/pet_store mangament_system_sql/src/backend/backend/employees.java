package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class employees {
    public static String generateEmployeeID(){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(employee_id) from employees");


            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        }
        catch (Exception e) {
            System.out.println("generateOrderID() error");
            System.out.println(e);
        }
        return "";
    }
    public static void add_employees(String emp_id,String fname,String lastname,String salaray,String jtype,String phoneno)
    {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into employees"
                    + " values (?, ?,?,?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString (1,emp_id);
            preparedStmt.setString(2,fname);
            preparedStmt.setString(3,lastname);
            preparedStmt.setString(4,salaray);
            preparedStmt.setString(5,jtype);
            preparedStmt.setString(6,phoneno);
            preparedStmt.executeUpdate();
            System.out.println("inserted employee");
        }
        catch (Exception e)
        {
            System.out.println("add_employee() error;");
            System.out.println(e);
        }
    }
    public static String viewemployees(){
        String s="";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from employees");
            ResultSet rs=queryStatement.executeQuery();

            while (rs.next())
            {
                s+=rs.getString(1)+"\t\t\t"+ rs.getString(2)+"\t\t\t"+
                        rs.getString(3)+"\t\t\t"+ rs.getString(4)+"\t\t\t"+rs.getString(5)+
                        "\t\t\t"+rs.getString(6)+"\n\n";
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        return s;
    }

    public static boolean searchemployee(String emp_id){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select employee_id" +
                    " from employees where employee_id = ?");
            queryStatement.setString(1,emp_id);
            ResultSet rs=queryStatement.executeQuery();
            if(rs.next())
            {
                if (rs.getString(1).equals(emp_id))
                    return true;
            }

        }
        catch (Exception e)
        {
            System.out.println("search_emplyee() error");
            System.out.println(e);
        }
        return false;
    }

    public static void delete_emplyee_record(String employee_id)
    {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM EMPLOYEES WHERE EMPLOYEE_ID = ?";
            PreparedStatement ps1= connection.prepareStatement(selectSQL);
            ps1.setString(1,employee_id);
            ps1.executeUpdate();

            System.out.println(" EMPLOYEE deleted successfully");
        }
        catch (Exception e)
        {
            System.out.println("delete_EMPLOYEE(); error");
            System.out.println(e);
        }

    }
    public static void update_employee(String fanme,String l_name,String salary,String jobtype,String phoneno,String id){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE employees "
                    + " SET first_name = ?, last_name=?,salary=?,job_type=? ,phone#=? "
                    + "WHERE employee_ID = ?");
            queryStatement.setString(1, fanme);
            queryStatement.setString(2, l_name);
            queryStatement.setString(3, salary);
            queryStatement.setString(4,jobtype);
            queryStatement.setString(5,phoneno);
            queryStatement.setString(6,id);
            queryStatement.executeUpdate();
            System.out.println("updatedemplyee");

        } catch (Exception e) {
            System.out.println("update_employee() error");
            System.out.println(e);
        }
    }

}
