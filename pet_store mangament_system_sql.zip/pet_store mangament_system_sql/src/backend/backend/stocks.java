package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class stocks {
    public static boolean newStock(String stock_id) {
        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select stock_id " +
                    "from stocks where stock_id=?");
            queryStatement.setString(1,stock_id);
            ResultSet result = queryStatement.executeQuery();
            while (result.next()) {
                if (result.getString(1).equals(stock_id)) {
                    System.out.println(result.getString(1));
                    return false;
                }
//                  System.out.println(result.getString(1) + "\t\t " + result.getString(2));
            }

        } catch (Exception e) {
            System.out.println("newStock() error");
            System.out.println(e);
        }
        return true;
    }

    public static String stock_supplier_name(String stockid) {
        Connection connection;
        try {
//            System.out.println("stock id is "+stockid);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select supplier " +
                    "from STOCKS where stock_id= ?");
            queryStatement.setString(1, stockid);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {

                return result.getString(1);
            }

        } catch (Exception e) {
            System.out.println("stock_supplier_name() error");
            System.out.println(e);
        }
        return "------";
    }

    public static void addnewStock(String stock_id, String supplier) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into stocks (stock_id,supplier)"
                    + " values (?, ?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, stock_id);
            preparedStmt.setString(2, supplier);
            System.out.println("inserted Stock");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(" addnewStock(); error ");
            System.out.println(e);
        }

    }
}
