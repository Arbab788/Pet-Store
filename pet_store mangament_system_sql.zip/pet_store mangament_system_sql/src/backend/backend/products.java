package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class products {

    public static String generateProductID() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(prod_id) from products");
            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }
            }
        }
        catch (Exception e) {
            System.out.println("generateProductID() error");
            System.out.println(e);
        }
        return "";
    }

    public static boolean searchproduct(String prod_id){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select prod_id" +
                    " from products where prod_id = ? ");
            queryStatement.setString(1,prod_id);
            ResultSet rs=queryStatement.executeQuery();

            if (rs.next())
            {
                if (rs.getString(1).equals(prod_id))
                    return true;
            }

        }
        catch (Exception e)
        {
            System.out.println("searchproduct() error");
            System.out.println(e);
        }
        return false;
    }
    public static void addProducts(String prod_id,String type,String stock_id)

    {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into products (prod_id,PRODUCT_TYPE,STOCKS_STOCK_ID)"
                    + " values (?, ?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString (1,prod_id);
            preparedStmt.setString(2,type);
            preparedStmt.setString(3,stock_id);
            System.out.println("inserted product");
            preparedStmt.executeUpdate();
        }
        catch (Exception e)
        {
            System.out.println("addProducts() error;");
            System.out.println(e);
        }

    }
    public static void delete_products(String prod_id)
    {
        Connection connection;

        try {
//            System.out.println("procduct id is " +prod_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM products WHERE prod_id = ? ";
            PreparedStatement ps1= connection.prepareStatement(selectSQL);
            ps1.setString(1, prod_id);
            ps1.executeUpdate();
            System.out.println("deleted successfully product");
        }
        catch (Exception e)
        {
            System.out.println("delete_products(); error");
            System.out.println(e);
        }

    }


}
