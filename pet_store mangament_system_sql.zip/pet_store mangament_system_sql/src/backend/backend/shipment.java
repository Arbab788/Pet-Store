package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class shipment {

    public static String generateshipmentID() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(shipping_id) from shipment");
            int count = 0;


            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        }
        catch (Exception e) {
            System.out.println("generateProductID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void add_shipment(String ship_id,String ship_order_DATE,String order_id)
    {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into shipment"
                    + " values (?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString (1,ship_id);
            preparedStmt.setString(2,ship_order_DATE);
            preparedStmt.setString(3,order_id);
            preparedStmt.executeUpdate();
//            System.out.println("inserted shipment");
//            JOptionPane.showMessageDialog(null,"order added successfully");
        }
        catch (Exception e)
        {
            System.out.println("add_shipment() error;");
            System.out.println(e);
        }
    }


}
