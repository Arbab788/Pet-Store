package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class vaccination {
    public static void addVaccine(String prod_id, String vacc_id, String name, String price) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into VACCINATION"
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, prod_id);
            preparedStmt.setString(2, vacc_id);
            preparedStmt.setString(3, price);
            preparedStmt.setString(4, name);
            preparedStmt.executeUpdate();
//            System.out.println("inserted vaccine");
        } catch (Exception e) {
            System.out.println("addvaccine() error;");
            System.out.println(e);
        }
    }

    public static String viewvaccination() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from VACCINATION");
            ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }

    public static boolean searchVacc(String vacc_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select VACCINATION_ID" +
                    " from VACCINATION where VACCINATION_ID = ?");
            queryStatement.setString(1, vacc_id);
            ResultSet rs = queryStatement.executeQuery();
            if (rs.next()) {
                if (rs.getString(1).equals(vacc_id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search_vacc() error");
            System.out.println(e);
        }
        return false;
    }

    public static void update_vacc(String price, String name, String vacid) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE VACCINATION "
                    + " SET price = ?, name=? "
                    + "WHERE VACCINATION_ID = ?");
            queryStatement.setString(1, price);
            queryStatement.setString(2, name);
            queryStatement.setString(3, vacid);
            queryStatement.executeUpdate();
//            System.out.println("updatedvacc");

        } catch (Exception e) {
            System.out.println("update_vacc() error");
            System.out.println(e);
        }

    }

    public static void delete_vacc(String vacc_id) {
        Connection connection;

        try {
//            System.out.println("pet_id="+pet_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM VACCINATION WHERE VACCINATION_ID = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, vacc_id);
            ps1.executeUpdate();

            System.out.println(" vaccination deleted successfully");
        } catch (Exception e) {
            System.out.println("delete_vacc(); error");
            System.out.println(e);
        }

    }

    public static String viewsearchedvacc(String vacc_id) {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from VACCINATION where VACCINATION_ID" +
                    " = ?");
            queryStatement.setString(1, vacc_id);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }
}
