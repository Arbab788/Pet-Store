package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class pet_food {
    public static void addPet_food(String prod_id,String food_id,String weight,String name,String price){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into PET_FOOD"
                    + " values (?, ?,?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString (1,prod_id);
            preparedStmt.setString(2,food_id);
            preparedStmt.setString(3,price);
            preparedStmt.setString(4,weight);
            preparedStmt.setString(5,name);
//            System.out.println("inserted pets_food");
            preparedStmt.executeUpdate();
        }
        catch (Exception e)
        {
            System.out.println("addPets_food() error;");
            System.out.println(e);
        }

    }
    public static String viewfood(){
        String s="";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from PET_FOOD");
            ResultSet rs=queryStatement.executeQuery();

            while (rs.next())
            {
                s+=rs.getString(1)+"\t\t\t"+ rs.getString(2)+"\t\t\t"+
                        rs.getString(3)+"\t\t\t"+ rs.getString(4)+"\t\t\t"+
                        rs.getString(5)+"\n\n";
            }

        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        return s;
    }
    public static boolean search_food(String food_id){
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select food_id" +
                    " from PET_FOOD where food_id = ?");
            queryStatement.setString(1,food_id);
            ResultSet rs=queryStatement.executeQuery();

            if(rs.next())
            {
                if (rs.getString(1).equals(food_id))
                    return true;
            }

        }
        catch (Exception e)
        {
            System.out.println("search_pet() error");
            System.out.println(e);
        }
        return false;
    }
    public static void updateFood(String food_id,String name,String weight,String price)
    {
        Connection connection;

        try {
            System.out.println("food is  = "+food_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE pet_food "
                    + " SET price = ?, name = ?,weight=? "
                    + "WHERE FOOD_ID = ?");
            queryStatement.setString(1,price);
            queryStatement.setString(2,name);
            queryStatement.setString(3,weight);
            queryStatement.setString(4,food_id);
            queryStatement.executeUpdate();
            System.out.println("food updated");

        }
        catch (Exception e)
        {
            System.out.println("update_food(); error");
            System.out.println(e);
        }
    }
    public static void deletefood(String food_id)
    {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM pet_food WHERE food_id = ?";
            PreparedStatement ps1= connection.prepareStatement(selectSQL);
            ps1.setString(1,food_id);
            ps1.executeUpdate();

            System.out.println("deleted successfully food");
        }
        catch (Exception e)
        {
            System.out.println("delete_Pets(); error");
            System.out.println(e);
        }
    }
    public static String viewsearchedFood(String food_id){
        String s="";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from PET_FOOD where food_id" +
                    " = ?");
            queryStatement.setString(1,food_id);
            ResultSet rs=queryStatement.executeQuery();

            if(rs.next())
            {
                s+=rs.getString(1)+"\t\t\t"+ rs.getString(2)+"\t\t\t"+
                        rs.getString(3)+"\t\t\t"+ rs.getString(4)+"\t\t\t"+
                        rs.getString(5)+"\n\n";
            }

        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        return s;
    }
}
