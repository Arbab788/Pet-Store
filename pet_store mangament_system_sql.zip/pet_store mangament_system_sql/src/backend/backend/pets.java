package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class pets {
    public static String generate_pet_ID() {
        Connection connection;
        try {
            System.out.println("locatonzip method");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * " +
                    "from PETS");
            int count = 0;


            ResultSet result = queryStatement.executeQuery();
//            result.last();?
            while (result.next()) {
                count++;
            }
            return String.valueOf(count + 1);


        } catch (Exception e) {
            System.out.println("generate_pet_ID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void addPets(String prod_id, String pet_id, String price, String color, String breed) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into pets (prod_id,pet_id,PRICE,COLOR,BREED)"
                    + " values (?, ?,?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, prod_id);
            preparedStmt.setString(2, pet_id);
            preparedStmt.setString(3, price);
            preparedStmt.setString(4, color);
            preparedStmt.setString(5, breed);
//            System.out.println("inserted pets");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("addPets() error;");
            System.out.println(e);
        }

    }

    public static String viewpets() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select " +
                    "PROD_ID,PET_ID,PRICE,COLOR,BREED" +
                    " from pets");
            ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\t\t\t" +
                        rs.getString(5) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;

    }

    public static boolean search_pet(String id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select pet_id" +
                    " from pets where pet_id = ?");
            queryStatement.setString(1, id);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                if (rs.getString(1).equals(id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search_pet() error");
            System.out.println(e);
        }
        return false;
    }

    public static void updatePet(String price, String color, String breed, String id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE pets "
                    + " SET price = ?, color = ?, breed=? "
                    + "WHERE pet_id = ?");
            queryStatement.setString(1, price);
            queryStatement.setString(2, color);
            queryStatement.setString(3, breed);
            queryStatement.setString(4, id);
            queryStatement.executeUpdate();

        } catch (Exception e) {
            System.out.println("updateCustomer() error");
            System.out.println(e);
        }

    }

    public static void delete_Pets(String pet_id) {
        Connection connection;

        try {
            System.out.println("pet_id=" + pet_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM pets WHERE pet_id = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, pet_id);
            ps1.executeUpdate();

//            System.out.println("deleted successfully");
        } catch (Exception e) {
            System.out.println("delete_Pets(); error");
            System.out.println(e);
        }

    }

    public static String get_prodcut_id(String pet_ID) {
        Connection connection;
        try {
//            System.out.println("address_streetNo()");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select pet_id,prod_id " +
                    "from pets where pet_id=");
            queryStatement.setString(1, pet_ID);
            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {

                return result.getString(1);
            }

        }
        catch (Exception e) {
            System.out.println("get_prod_id() error");
            System.out.println(e);
        }
        return "-----";

    }
}

