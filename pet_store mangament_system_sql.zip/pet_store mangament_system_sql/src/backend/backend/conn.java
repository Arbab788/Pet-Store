package backend;
import java.sql.*;

public class conn {
    public static void main(String[] args) {
        Connection connection;
        try {

            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");

            PreparedStatement queryStatement = connection.prepareStatement("select employee_id, first_name, last_name, salary from employees where salary > 2500");

            ResultSet result = queryStatement.executeQuery();
            System.out.println("ID\tFirst Name\tLast Name\tSalary");
            while (result.next()) {
                System.out.println(result.getString(1) + "\t" + result.getString(2) + "\t" + result.getString(3) + "\t" + result.getString(4));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
