package backend;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class receipts {
    public static String generate_receipt_ID() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(receipts_id) from receipts");
            int count = 0;


            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        }
        catch (Exception e) {
            System.out.println("generate_receipt_ID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void add_receipt(String receipt_id, String biling_DATE, String paid_amount, String order_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into RECEIPTS"
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, receipt_id);
            preparedStmt.setString(2, biling_DATE);
            preparedStmt.setString(3, paid_amount);
            preparedStmt.setString(4, order_id);
            preparedStmt.executeUpdate();
//            System.out.println("inserted receipts");
            JOptionPane.showMessageDialog(null, "receipt added successfully");
        } catch (Exception e) {
            System.out.println("add_orders() error;");
            System.out.println(e);
        }
    }

    public static boolean neworder(String order_id) {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select ORDER_ORDER_ID" +
                    " from receipts where ORDER_ORDER_ID=?");
            queryStatement.setString(1,order_id);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                return false;
            }

        } catch (Exception e) {
            System.out.println("new order() error");
            System.out.println(e);
        }
        return true;
    }


    public static boolean search_receipt(String receipt_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select receipts_id" +
                    " from receipts where receipts_id = ? ");
            queryStatement.setString(1, receipt_id);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                if (rs.getString(1).equals(receipt_id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search receipt() error");
            System.out.println(e);
        }
        return false;
    }

    public static void delete_receipt(String order_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM receipts WHERE receipts_id = ? ";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, order_id);
            ps1.executeUpdate();
            System.out.println("deleted successfully receipt");
        } catch (Exception e) {
            System.out.println("delete_order(); error");
            System.out.println(e);
        }

    }


}
