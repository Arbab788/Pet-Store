package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class accessories {
    public static void add_new_accessories(String prd_id, String accs_id, String price, String name) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "petstore1", "pass123");
            String query = " insert into ACCESSORIES "
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, prd_id);
            preparedStmt.setString(2, accs_id);
            preparedStmt.setString(3, price);
            preparedStmt.setString(4, name);
            System.out.println("inserted accessories");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("add_new_accessories(); error");
            System.out.println(e);
        }
    }

    public static String viewAccessories() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "petstore1", "pass123");
            PreparedStatement queryStatement = connection.prepareStatement("select *" +
                    " from ACCESSORIES");
            ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }

    public static boolean search_accessories(String acc_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "petstore1", "pass123");
            PreparedStatement queryStatement = connection.prepareStatement("select ACCESSORIES_ID" +
                    " from ACCESSORIES where ACCESSORIES_ID= ? ");
            queryStatement.setString(1, acc_id);
            ResultSet rs = queryStatement.executeQuery();

            if(rs.next()) {
                if (rs.getString(1).equals(acc_id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search_pet() error");
            System.out.println(e);
        }
        return false;
    }

    public static void update_accessoreis(String price, String name, String ac_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "petstore1", "pass123");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE ACCESSORIES "
                    + " SET price = ?, name = ? "
                    + "WHERE ACCESSORIES_ID = ?");
            queryStatement.setString(1, price);
            queryStatement.setString(2, name);
            queryStatement.setString(3, ac_id);
            queryStatement.executeUpdate();
            System.out.println("accessory updated");

        } catch (Exception e) {
            System.out.println("update_accessoreis(); error");
            System.out.println(e);
        }

    }

    public static void delete_accessories(String asc_id) {
        Connection connection;

        try {
//            System.out.println("pet_id="+pet_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM ACCESSORIES WHERE ACCESSORIES_ID = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, asc_id);
            ps1.executeUpdate();

            System.out.println("accessoriy deleted successfully");
        } catch (Exception e) {
            System.out.println("delete_accessories() error;");
            System.out.println(e);
        }

    }

    public static String display_search_assc(String ascId) {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select *" +
                    " from ACCESSORIES where ACCESSORIES_ID=?");
            queryStatement.setString(1, ascId);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {

                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }
}
