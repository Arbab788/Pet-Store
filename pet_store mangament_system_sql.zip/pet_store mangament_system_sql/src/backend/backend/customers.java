package backend;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class customers {
    private String last_name;
    private String first_name;
    private String customer_id;
    private String address_id;

    public customers(String last_name, String first_name, String customer_id, String address_id) {
        this.last_name = last_name;
        this.first_name = first_name;
        this.customer_id = customer_id;
        this.address_id = address_id;
    }

    public static boolean isStringOnlyAlphabet(String str) {
        return ((!str.equals(""))
                && (str != null)
                && (str.matches("^[a-zA-Z]*$")));
    }

    public static boolean isdigitOnly(String str) {
        if (str.length() > 37)
            return false;
        String regex = "[0-9]+";

        // Compile the ReGex
        Pattern p = Pattern.compile(regex);

        // If the string is empty
        // return false
        if (str == null) {
            return false;
        }

        // Find match between given string
        // and regular expression
        // using Pattern.matcher()
        Matcher m = p.matcher(str);

        // Return if the string
        // matched the ReGex
        return m.matches();
    }

    public static boolean uniqueCustomer(String cusID) {
        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select customer_id " +
                    "from CUSTOMERS where customer_id= ? ");
            queryStatement.setString(1, cusID);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                if (result.getString(1).equals(cusID))
                    return false;
            }

        }
        catch (Exception e) {
            System.out.println("unique customer error");
            System.out.println(e);
        }
        return true;
    }

    public static String generatedCustomerId() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(customer_id) from customers");
            int count = 0;


            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        }
        catch (Exception e) {
            System.out.println("generateProductID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void addnewcustomer(String customer_id, String fname, String lstname, String addressid) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into customers (customer_id,first_name,last_name,address_address_id)"
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, customer_id);
            preparedStmt.setString(2, fname);
            preparedStmt.setString(3, lstname);
            preparedStmt.setString(4, addressid);
//            System.out.println("inserted customer");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("add customer error");
            System.out.println(e);
        }

    }

    public static String viewCustomers() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select customer_id,first_name,last_name,address_address_id" +
                    " from customers");
            ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }

    public static void deleteCustomer(String cusID) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM CUSTOMERS WHERE CUSTOMER_ID = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, cusID);
            ps1.executeUpdate();
            System.out.println("deleted successfully");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static boolean searchCustomerID(String cusid) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select customer_id" +
                    " from customers where customer_id= ? ");
            queryStatement.setString(1, cusid);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                if (rs.getString(1).equals(cusid))
                    return true;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public static void updateCustomer(String id, String fname, String lname) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE customers "
                    + " SET first_name = ?, last_name = ? "
                    + "WHERE customer_id = ?");
            queryStatement.setString(1, fname);
            queryStatement.setString(2, lname);
            queryStatement.setString(3, id);
            queryStatement.executeUpdate();

        } catch (Exception e) {
            System.out.println("updateCustomer() error");
            System.out.println(e);
        }

    }
    public static String custoemr_name(String id) {
        Connection connection;
        try {
            System.out.println("address_streetNo()");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select first_name " +
                    "from customers where customer_id= ? ");
            queryStatement.setString(1, id);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                return result.getString(1);
            }
        } catch (Exception e) {
            System.out.println("customer_name() error");
            System.out.println(e);
        }
        return "-----";
    }


}
