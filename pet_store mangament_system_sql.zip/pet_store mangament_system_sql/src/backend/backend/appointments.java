package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class appointments {
    public static String generate_appt_ID() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(appointment_id) from appointments");
            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        } catch (Exception e) {
            System.out.println("generate_appt_ID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void add_appt(String appt_id,String pet,String date,String doc_id)

    {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into appointments"
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString (1,appt_id);
            preparedStmt.setString(2,pet);
            preparedStmt.setString(3,date);
            preparedStmt.setString(4,doc_id);
            preparedStmt.executeUpdate();

        }
        catch (Exception e)
        {
            System.out.println("adddoctor() error;");
            System.out.println(e);
        }

    }

    public static String view_appts() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from appointments");
            ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\t\t\t" +
                        rs.getString(3) + "\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }

    public static boolean search_appts(String appt_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select appointment_id" +
                    " from appointments where appointment_id = ? ");
            queryStatement.setString(1, appt_id);
            ResultSet rs = queryStatement.executeQuery();
            if (rs.next()) {
                if (rs.getString(1).equals(appt_id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search_appt() error");
            System.out.println(e);
        }
        return false;
    }

    public static void delete_appointments(String doc_id) {
        Connection connection;

        try {
//            System.out.println("pet_id="+pet_id);
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM appointments WHERE appointment_id = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, doc_id);
            ps1.executeUpdate();

            System.out.println(" appointment deleted successfully");
        } catch (Exception e) {
            System.out.println("delete_apt(); error");
            System.out.println(e);
        }

    }
}
