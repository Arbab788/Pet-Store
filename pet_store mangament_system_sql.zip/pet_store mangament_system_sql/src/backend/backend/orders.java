package backend;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class orders {
    public static String generateOrderID() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("SELECT MAX(order_id) from orders");
            int count = 0;


            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1) == null) {
                    return "1";
                } else {
                    String s = Integer.valueOf(result.getString(1)) + 1 + "";
                    return s;
                }

            }


        }
        catch (Exception e) {
            System.out.println("generateOrderID() error");
            System.out.println(e);
        }
        return "";
    }

    public static void add_orders(String order_id, String order_DATE, String customer_id, String prod_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into orders"
                    + " values (?, ?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, order_id);
            preparedStmt.setString(2, order_DATE);
            preparedStmt.setString(3, customer_id);
            preparedStmt.setString(4, prod_id);
            preparedStmt.executeUpdate();
            System.out.println("inserted orders");
            JOptionPane.showMessageDialog(null, "order added successfully");
        } catch (Exception e) {
            System.out.println("add_orders() error;");
            System.out.println(e);
        }
    }

    public static boolean productAvailable(String prod_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select PRODUCTS_PROD_ID" +
                    " from orders where PRODUCTS_PROD_ID = ? ");
            queryStatement.setString(1, prod_id);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                if (rs.getString(1).equals(prod_id))
                    return false;
            }

        } catch (Exception e) {
            System.out.println("prod_avalialbe() error");
            System.out.println(e);
        }
        return true;
    }

    public static String vieworders() {
        String s = "";
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select * from orders");
                    ResultSet rs = queryStatement.executeQuery();

            while (rs.next()) {
                s += rs.getString(1) + "\t\t\t\t" + rs.getString(2) + "\t\t\t\t" +
                        rs.getString(3) + "\t\t\t\t" + rs.getString(4) + "\n\n";
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return s;
    }

    public static boolean searchorder(String order_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select order_id" +
                    " from orders where order_id = ? ");
            queryStatement.setString(1, order_id);
            ResultSet rs = queryStatement.executeQuery();

           if(rs.next()) {
                if (rs.getString(1).equals(order_id))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("search order() error");
            System.out.println(e);
        }
        return false;
    }

    public static void delete_order(String order_id) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM orders WHERE order_id = ? ";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, order_id);
            ps1.executeUpdate();
            System.out.println("deleted successfully order");
        } catch (Exception e) {
            System.out.println("delete_order(); error");
            System.out.println(e);
        }

    }

}
