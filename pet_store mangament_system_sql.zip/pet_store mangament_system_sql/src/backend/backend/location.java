package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class location {
    public static boolean newLocation(String locID) {
        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select location_id " +
                    "from location where location_id= ? ");
            queryStatement.setString(1, locID);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                if (result.getString(1).equals(locID)) {
                    System.out.println(result.getString(1));
                    return false;
                }
//                  System.out.println(result.getString(1) + "\t\t " + result.getString(2));
            }

        } catch (Exception e) {
            System.out.println("new locationid error");
            System.out.println(e);
        }
        return true;
    }

    public static String locationName(String locID) {
        Connection connection;
        try {
//            System.out.println("location name method");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select name " +
                    "from location where location_id = ? ");
            queryStatement.setString(1,locID);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                return result.getString(1);
            }

        } catch (Exception e) {

            System.out.println(e);
        }
        return "------";
    }


    public static String location_zipcode(String locID) {
        Connection connection;
        try {
//            System.out.println("locatonzip method");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select zipcode " +
                    "from location where location_id= ? ");
            queryStatement.setString(1,locID);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                return result.getString(1);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return "------";
    }

    public static void addLocation(String locId, String locName, String zipcode) {
        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into location (location_id,name,zipcode)"
                    + " values (?, ?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, locId);
            preparedStmt.setString(2, locName);
            preparedStmt.setString(3, zipcode);
//            System.out.println("inserted location");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("addLocation(); error");

            System.out.println(e);
        }
    }
}


