package backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class address {
    public static boolean uniqueaddress(String adressID) {

        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select address_id " +
                    "from address where address_id = ?");
            queryStatement.setString(1, adressID);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                if (result.getString(1).equals(adressID)) {
                    System.out.println(result.getString(1));
                    return false;
                }
            }
        } catch (Exception e) {
            System.out.println("unique address method error");
            System.out.println(e);
        }
        return true;
    }


    public static String address_HouseNo(String address_id) {
        Connection connection;
        try {
//            System.out.println("address_HouseNo()");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select address_id,house# " +
                    "from address where address_id= ? ");
            queryStatement.setString(1, address_id);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                if (result.getString(1).equals(address_id))
                    return result.getString(2);

            }
        } catch (Exception e) {
            System.out.println("address_HouseNo() error");
            System.out.println(e);
        }
        return "----";
    }

    public static String address_streetNo(String address_id) {
        Connection connection;
        try {
//            System.out.println("address_streetNo()");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select street# " +
                    "from address where address_id= ? ");
            queryStatement.setString(1, address_id);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                return result.getString(1);
            }
        } catch (Exception e) {
            System.out.println("address_streetNo() error");
            System.out.println(e);
        }
        return "-----";
    }


    public static void add_new_address(String address_id, String houseno, String streetno, String locationID) {
        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into address (house#,street#,address_id,location_location_id)"
                    + " values (?,?,?,?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, houseno);
            preparedStmt.setString(2, streetno);
            preparedStmt.setString(3, address_id);
            preparedStmt.setString(4, locationID);
//            System.out.println("inserted address");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("add new address method error");
            System.out.println(e);
        }
    }

    public static String address_locationID(String address_id) {
        Connection connection;
        try {

            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select LOCATION_LOCATION_ID " +
                    "from address where address_id= ? ");
            queryStatement.setString(1, address_id);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                return result.getString(1);
            }
        } catch (Exception e) {
            System.out.println("address_locid() error");
            System.out.println(e);
        }
        return "-----";
    }
}
