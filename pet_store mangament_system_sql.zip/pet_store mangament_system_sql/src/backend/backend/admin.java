package backend;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class admin {
    private String user_name;
    private String password;
    private static conn c1;

    public admin(String user_name, String password) {
        this.user_name = user_name;
        this.password = password;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static boolean isuniqueUser(String username) {
        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select user_name, " +
                    "password from admin where user_name= ? ");
            queryStatement.setString(1, username);
            ResultSet result = queryStatement.executeQuery();
            if (result.next()) {
                if (result.getString(1).equals(username))
                    return false;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return true;
    }

    public static boolean checkSignin(String username, String password) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select user_name, " +
                    "password from admin WHERE user_name= ? and password= ? ");
            queryStatement.setString(1, username);
            queryStatement.setString(2, password);
            ResultSet result = queryStatement.executeQuery();

            if (result.next()) {
                if (result.getString(1).equals(username) && result.getString(2).equals(password))
                    return true;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return false;

    }

    public static void connectionsetup() {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void addNewUser(String user_name, String password) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String query = " insert into admin (user_name,password)"
                    + " values (?, ?)";
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setString(1, user_name);
            preparedStmt.setString(2, password);
            System.out.println("inserted");
            preparedStmt.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }


    }

    public static boolean validPassword(String password) {
        if (password.length() >= 7) {
            return true;
        }
        return false;
    }

    public static boolean validUserName(String name) {
        // Regex to check valid username.
        String regex = "^[A-Za-z]\\w{5,29}$";

        // Compile the ReGex
        Pattern p = Pattern.compile(regex);

        // If the username is empty
        // return false
        if (name == null) {
            return false;
        }

        Matcher m = p.matcher(name);

        // Return if the username
        // matched the ReGex
        return m.matches();
    }

    public static void deleteUsers(String name) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            String selectSQL = "DELETE FROM ADMIN WHERE user_name = ?";
            PreparedStatement ps1 = connection.prepareStatement(selectSQL);
            ps1.setString(1, name);
            ps1.executeUpdate();
            System.out.println("deleted successfully");
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public static void updateUser(String pas, String name) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("UPDATE admin "
                    + " SET password = ? "
                    + "WHERE user_name = ?");
            queryStatement.setString(1, pas);
            queryStatement.setString(2, name);
            ResultSet rs = queryStatement.executeQuery();

        } catch (Exception e) {
            System.out.println("updateUser(); error");
            System.out.println(e);
        }

    }

    public static boolean searchUser(String name) {
        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select user_name, " +
                    "password from admin where user_name = ? ");
            queryStatement.setString(1, name);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                if (rs.getString(1).equals(name))
                    return true;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    public static String currentAdmin(String name) {
        return name;
    }

    public static String viewUsers() {
        String s = "";
            Connection connection;

            try {
                connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                PreparedStatement queryStatement = connection.prepareStatement("select user_name, " +
                        "password from admin");
                ResultSet rs = queryStatement.executeQuery();


                while (rs.next()) {
                    s += rs.getString(1) + "\t\t\t" + rs.getString(2) + "\n\n";
                }

            } catch (Exception e) {
                System.out.println(e);
            }
        return s;
    }

    public static boolean passwordMatch(String name, String pass) {

        Connection connection;

        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
            PreparedStatement queryStatement = connection.prepareStatement("select password " +
                    " from admin where user_name= ? ");
            queryStatement.setString(1, name);
            ResultSet rs = queryStatement.executeQuery();

            if (rs.next()) {
                if (rs.getString(1).equals(pass))
                    return true;
            }

        } catch (Exception e) {
            System.out.println("password_match(); ");
            System.out.println(e);
        }
        return false;
    }

}
