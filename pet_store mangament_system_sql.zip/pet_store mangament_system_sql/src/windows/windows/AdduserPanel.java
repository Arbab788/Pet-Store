package windows;

import backend.admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdduserPanel extends JDialog {

    private JPanel contentPane;
    private JLabel password_lbl;
    private JLabel confirmpassword_lbl;
    private JTextField usrname_textField;
    private JPasswordField passwordField;
    private JPasswordField passwordField_1;
    private JLabel error_lable;
    private JButton create_user_btn;
    private JPanel panel;

    public AdduserPanel() {
        setBounds(119, 11, 688, 483);
        getContentPane().setLayout(null);

        panel = new JPanel();
        panel.setFont(new Font("Tahoma", Font.BOLD, 13));
        panel.setBackground(new Color(255, 255, 255));
        panel.setBounds(0, 0, 672, 444);
        getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(Color.LIGHT_GRAY);

        JLabel User_name_lbl = new JLabel("User Name");
        User_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        User_name_lbl.setBounds(54, 102, 122, 33);
        panel.add(User_name_lbl);

        password_lbl = new JLabel("PASSWORD");
        password_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        password_lbl.setBounds(54, 147, 122, 40);
        panel.add(password_lbl);

        confirmpassword_lbl = new JLabel("Confrim Password");
        confirmpassword_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        confirmpassword_lbl.setBounds(54, 193, 122, 40);
        panel.add(confirmpassword_lbl);

        usrname_textField = new JTextField();
        usrname_textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        usrname_textField.setBounds(186, 109, 192, 20);
        panel.add(usrname_textField);
        usrname_textField.setColumns(10);

        passwordField = new JPasswordField();
        passwordField.setBounds(186, 158, 192, 20);
        panel.add(passwordField);

        passwordField_1 = new JPasswordField();
        passwordField_1.setBounds(186, 204, 192, 20);
        panel.add(passwordField_1);

        error_lable = new JLabel("error to be dislplayed here");
        error_lable.setForeground(new Color(204, 0, 0));
        error_lable.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
        error_lable.setBounds(217, 244, 386, 33);
        panel.add(error_lable);
        error_lable.setVisible(false);

        create_user_btn = new JButton("Create User");
        create_user_btn.setBounds(186, 288, 192, 40);
        create_user_btn.setBackground(new Color(0xEFF0E7));
        panel.add(create_user_btn);
        ActionListener a1 = new actionListener();
        create_user_btn.addActionListener(a1);


    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(create_user_btn)) {
                if (!admin.isuniqueUser(usrname_textField.getText())){
                    error_lable.setText("user already exists");
                    error_lable.setVisible(true);
                }
                else if (!admin.validUserName(usrname_textField.getText()))
                {
                    error_lable.setText("invalid user name(must of at least of length 6)");
                    error_lable.setVisible(true);
                }
                else if (!admin.validPassword(String.valueOf(passwordField.getPassword())))
                {
                    error_lable.setVisible(true);
                    error_lable.setText("invalid password");
                }
                else if (!(String.valueOf(passwordField.getPassword()).equals(String.valueOf(passwordField_1.getPassword()))))
                {
                    error_lable.setText("invalid password ");
                    error_lable.setVisible(true);
                }
                else
                {
                    admin.addNewUser(usrname_textField.getText(),String.valueOf(passwordField.getPassword()));
                    error_lable.setText("user created");
                    error_lable.setForeground(Color.BLUE);
                    error_lable.setVisible(true);
                    usrname_textField.setText("");
                    passwordField.setText("");
                    passwordField_1.setText("");
                }

            }
        }
    }

}
