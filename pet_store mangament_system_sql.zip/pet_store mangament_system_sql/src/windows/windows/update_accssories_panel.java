package windows;

import backend.accessories;
import backend.customers;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class update_accssories_panel extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton update_btn;
    private JLabel accessiories_price_lbl;
    private JTextField accessiories_price_textField_2;
    private JLabel accessiories_ERRor_lbl;
    private JLabel accessiories_name_lbl;
    private JLabel accessory_added_msg_lbl;
    private JLabel supplier_name_lbl;
    private JComboBox comboBox;
    private  String acsId;
    public update_accssories_panel(String id) {
        acsId=id;
     initialize();
    }
    private void initialize(){
        setBounds(100, 100, 560, 400);
        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        update_btn = new JButton("UPDATE");
        update_btn.setBackground(Color.GRAY);
        update_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_btn.setForeground(Color.WHITE);
        update_btn.setBounds(170, 231, 133, 35);
        panel.add(update_btn);

        accessiories_price_lbl = new JLabel("PRICE");
        accessiories_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        accessiories_price_lbl.setBounds(10, 117, 119, 27);
        panel.add(accessiories_price_lbl);

        accessiories_price_textField_2 = new JTextField();
        accessiories_price_textField_2.setColumns(10);
        accessiories_price_textField_2.setBounds(139, 118, 184, 27);
        panel.add(accessiories_price_textField_2);

        accessiories_ERRor_lbl = new JLabel("DIGITS ONLY");
        accessiories_ERRor_lbl.setForeground(Color.RED);
        accessiories_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        accessiories_ERRor_lbl.setBounds(345, 117, 199, 27);
        panel.add(accessiories_ERRor_lbl);

        accessiories_name_lbl = new JLabel("NAME");
        accessiories_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        accessiories_name_lbl.setBounds(10, 155, 119, 27);
        panel.add(accessiories_name_lbl);

        accessory_added_msg_lbl = new JLabel("Accessory UPDATED");
        accessory_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
        accessory_added_msg_lbl.setForeground(Color.RED);
        accessory_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        accessory_added_msg_lbl.setBounds(173, 193, 199, 27);
        panel.add(accessory_added_msg_lbl);


        String accessorieis[]={"collar","rope","chain","playball","form shampoo","food bowl"};
        comboBox = new JComboBox(accessorieis);
        comboBox.setBounds(139, 156, 184, 26);
        panel.add(comboBox);
        ActionListener a1=new actionListener();
        update_btn.addActionListener(a1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            System.out.println("updated button pressed");
            if (!customers.isdigitOnly(accessiories_price_textField_2.getText()))
            {
                System.out.println("preice issue");
            }
            else {
                accessories.update_accessoreis(accessiories_price_textField_2.getText(),
                        String.valueOf(comboBox.getSelectedItem()),acsId);
                JOptionPane.showMessageDialog(null,"updated");
                setVisible(false);
            }
        }
    }

}