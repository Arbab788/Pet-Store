package windows;

import backend.address;
import backend.customers;
import backend.location;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class customer_managment extends JFrame {

    private JPanel contentPane;
    private JButton add_customer_btn;
    private JButton view_customer_btn_1;
    private JButton update_customer_btn;
    private JScrollPane scroll;
    private JButton sales_management_btn;
    private JTextArea textFiled;
    private JButton delete_customer_btn;

    public customer_managment() {
        initialize();
    }
    private void initialize(){
        ActionListener a1=new actionListener();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(0, 0, 784, 475);
        contentPane.add(panel);
        panel.setLayout(null);
        panel.setBackground(SystemColor.activeCaption);

        add_customer_btn = new JButton("Add customer");
        add_customer_btn.setBounds(10, 26, 132, 42);
        panel.add(add_customer_btn);
        add_customer_btn.setBackground(SystemColor.info);
        add_customer_btn.addActionListener(a1);

        view_customer_btn_1 = new JButton("view customer");
        view_customer_btn_1.setBounds(219, 26, 132, 42);
        panel.add(view_customer_btn_1);
        view_customer_btn_1.addActionListener(a1);
        view_customer_btn_1.setBackground(SystemColor.info);

        update_customer_btn = new JButton("update customer");
        update_customer_btn.setBounds(419, 26, 132, 42);
        panel.add(update_customer_btn);
        update_customer_btn.addActionListener(a1);
        update_customer_btn.setBackground(SystemColor.info);

        delete_customer_btn = new JButton("delete customer");
        delete_customer_btn.setBounds(621, 26, 132, 42);
        panel.add(delete_customer_btn);
//        textFiled = new JTextArea();
//        textFiled.setWrapStyleWord(true);
//        textFiled.setBounds(141, 238, 561, 83);
        delete_customer_btn.addActionListener(a1);
        delete_customer_btn.setBackground(SystemColor.info);

//        panel.add(textFiled);
        scroll = new JScrollPane();
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);
        sales_management_btn = new JButton("sales managmment");
        sales_management_btn.setBounds(10, 94, 162, 33);
        panel.add(sales_management_btn);
        sales_management_btn.addActionListener(a1);
        sales_management_btn.setBackground(SystemColor.info);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_customer_btn))
            {
                add_customer a1=new add_customer();
                a1.setVisible(true);
            }
            else if (a.getSource().equals(view_customer_btn_1))
            {


            try {
                Connection connection;
                connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                PreparedStatement queryStatement = connection.prepareStatement("select * " +
                        "from customers");
                ResultSet rs = queryStatement.executeQuery();
                JTable table = new JTable();
                table.setModel(new DefaultTableModel(
                        new Object[][] {
                        },
                        new String[] {
                                "ID ", "FirstName","lastName","house#","Street#","location"
                        }
                ) {
                    Class[] columnTypes = new Class[] {
                            String.class, String.class,String.class,String.class,String.class,String.class
                    };
                    public Class getColumnClass(int columnIndex) {
                        return columnTypes[columnIndex];
                    }
                    boolean[] columnEditables = new boolean[] {
                            false, false,false,false,false,false
                    };
                    public boolean isCellEditable(int row, int column) {
                        return columnEditables[column];
                    }
                });
                scroll.setViewportView(table);
                DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                while (rs.next()) {
                    String tbData[]={rs.getString(1),rs.getString(2),rs.getString(3),
                            address.address_HouseNo(rs.getString(4)),address.address_streetNo(rs.getString(4)),
                            location.locationName(address.address_locationID(rs.getString(4)))};
                    tbModel.addRow(tbData);

                }

            } catch (Exception e) {
                System.out.println(e);
            }

//                String s="customerID\t\t\tFirstName\t\t\tLastName\t\t\tAddressID\n"+"-------------------" +
//                        "--------------------------------------------" +
//                        "----------------------------------------------------------------" +
//                        "-----------------------------------------" +
//                        "--\n\n";
//                scroll.setVisible(true);
//                textFiled.setText(s+ customers.viewCustomers());
//                textFiled.setEditable(false);
//                scroll.isEnabled();
//                textFiled.setFont(new Font("Tahoma", Font.BOLD, 13));
            }
            else if (a.getSource().equals(update_customer_btn))
            {
                String o_id = JOptionPane.showInputDialog("enter customer id you want ot update");
                if (customers.searchCustomerID(o_id))
                {
                    update_customer a1=new update_customer(o_id);
                    a1.setVisible(true);

                }
                else
                    JOptionPane.showMessageDialog(null,"no such customer found");

            }
            else if (a.getSource().equals(delete_customer_btn))
            {
                String o_id="";
                o_id = JOptionPane.showInputDialog("enter customer id you want to delete");
                if (customers.searchCustomerID(o_id))
                {
                    customers.deleteCustomer(o_id);
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                }
                else
                    JOptionPane.showMessageDialog(null,"no such customer found");

            }
            else if (a.getSource().equals(sales_management_btn))
            {
                sales_management s1=new sales_management();
                s1.setVisible(true);
                dispose();
            }
        }
    }

}
