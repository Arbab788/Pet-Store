package windows;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class services_management extends JFrame {

    private JPanel contentPane;
    private JButton doctor_btn;
    private JButton appointments_btn;
    private JButton homepage_btn;
    private JPanel panel;


    public services_management() {
        initialize();

    }
    private  void initialize(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);


        doctor_btn = new JButton("DOCTORS");
        doctor_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        doctor_btn.setBackground(SystemColor.info);
        doctor_btn.setBounds(29, 25, 142, 51);
        panel.add(doctor_btn);

        appointments_btn = new JButton("APPOINTMENTS");
        appointments_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        appointments_btn.setBackground(SystemColor.info);

        appointments_btn.setBounds(207, 25, 142, 51);
        panel.add(appointments_btn);

        homepage_btn = new JButton("BACK");
        homepage_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        homepage_btn.setBounds(29, 87, 142, 30);
        panel.add(homepage_btn);
        homepage_btn.setBackground(SystemColor.info);
        ActionListener a1=new actionListener();
        doctor_btn.addActionListener(a1);
        appointments_btn.addActionListener(a1);
        homepage_btn.addActionListener(a1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(doctor_btn))
            {
                doctors_management d1=new doctors_management();
                d1.setVisible(true);
                dispose();
            }
            else if (a.getSource().equals(appointments_btn))
            {
                appointments_management a1=new appointments_management();
                a1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(homepage_btn)) {
                homePage h1 = new homePage();
                h1.setVisible(true);
                dispose();
            }
        }
    }

}
