package windows;

import backend.customers;
import backend.pet_food;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class update_petFood_panel extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton update_btn;
    private JLabel pet_added_msg_lbl;
    private JLabel food_price_lbl;
    private JTextField textField_4;
    private JLabel price_ERRor_lbl;
    private JComboBox comboBox;
    private JLabel weight_lbl;
    private JLabel food_name_lbl_1;
    private JComboBox foodname_comboBox_1;
    private String fid;

    public update_petFood_panel(String food_id) {
        fid=food_id;
        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        update_btn = new JButton("UPDATE");
        update_btn.setBackground(Color.GRAY);
        update_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_btn.setForeground(Color.WHITE);
        update_btn.setBounds(166, 248, 133, 35);
        panel.add(update_btn);

//        pet_added_msg_lbl = new JLabel("Employee Added");
//        pet_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
//        pet_added_msg_lbl.setForeground(Color.RED);
//        pet_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
//        pet_added_msg_lbl.setBounds(166, 210, 199, 27);
//        panel.add(pet_added_msg_lbl);

        String s1[]= {"1","2","3","4","5","10","20"};

        food_price_lbl = new JLabel("PRICE");
        food_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        food_price_lbl.setBounds(10, 91, 119, 27);
        panel.add(food_price_lbl);

        textField_4 = new JTextField();
        textField_4.setColumns(10);
        textField_4.setBounds(139, 92, 184, 27);
        panel.add(textField_4);

        price_ERRor_lbl = new JLabel("DIGITS ONLY");
        price_ERRor_lbl.setForeground(Color.RED);
        price_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        price_ERRor_lbl.setBounds(345, 91, 199, 27);
        panel.add(price_ERRor_lbl);

        comboBox = new JComboBox(s1);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
        comboBox.setBounds(139, 130, 184, 27);
        panel.add(comboBox);

        weight_lbl = new JLabel("WEIGHT (kg )");
        weight_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        weight_lbl.setBounds(10, 129, 119, 27);
        panel.add(weight_lbl);

        food_name_lbl_1 = new JLabel("Food name");
        food_name_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        food_name_lbl_1.setBounds(10, 168, 119, 27);
        panel.add(food_name_lbl_1);

        String fooods[]={"biscuit","milk","bones","meatballs"};
        foodname_comboBox_1 = new JComboBox(fooods);
        foodname_comboBox_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        foodname_comboBox_1.setBounds(139, 172, 184, 27);
        panel.add(foodname_comboBox_1);
        ActionListener a1=new actionListener();
        update_btn.addActionListener(a1);

    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(update_btn))
            {
                System.out.println("updared bnt asdad");
                if (!customers.isdigitOnly(textField_4.getText())){
                    System.out.println("invlaid price");
                }
                else
                {

                    System.out.println("updateing");
                    pet_food.updateFood(fid,String.valueOf(foodname_comboBox_1.getSelectedItem()),
                            String.valueOf(comboBox.getSelectedItem()),textField_4.getText());
                    JOptionPane.showMessageDialog(null,"updated");
                    setVisible(false);
                }
            }

        }
    }


        }
