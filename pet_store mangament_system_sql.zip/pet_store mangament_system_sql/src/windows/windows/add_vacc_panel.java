package windows;

import backend.customers;
import backend.products;
import backend.stocks;
import backend.vaccination;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_vacc_panel extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JLabel Product_id_lbl;
    private JTextField productIDtextField;
    private JLabel productID_ERRor_lbl;
    private JLabel vacc_id_lbl;
    private JTextField vacc_id_textField_1;
    private JLabel vacc_ERRor_lbl;
    private JLabel vacc_price_lbl;
    private JTextField price_textField_2;
    private JLabel price_ERRor_lbl;
    private JLabel vacc_name_lbl;
    private JComboBox comboBox;
    private JLabel stock_id__ERRor_lbl;
    private JTextField textField;
    private JLabel stock_id_lbl;
    private JLabel supplier_name_lbl;
    private JTextField textField_1;
    private JLabel suppliername_ERRor_lbl;
    private JLabel pet_added_msg_lbl;
    private JButton add_btn;

   public add_vacc_panel() {
       initialize();
    }
    private void initialize(){
       ActionListener a1=new actionListener();

        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        Product_id_lbl = new JLabel("PROUCT ID");
        Product_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        Product_id_lbl.setBounds(10, 37, 119, 27);
        panel.add(Product_id_lbl);

        productIDtextField = new JTextField();
        productIDtextField.setColumns(10);
        productIDtextField.setBounds(139, 38, 184, 27);
        panel.add(productIDtextField);

        productID_ERRor_lbl = new JLabel("DIGITS ONLY(max 37 digits)");
        productID_ERRor_lbl.setForeground(Color.RED);
        productID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        productID_ERRor_lbl.setBounds(345, 37, 199, 27);
        panel.add(productID_ERRor_lbl);

        vacc_id_lbl = new JLabel("VACCINATION ID");
        vacc_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        vacc_id_lbl.setBounds(10, 79, 119, 27);
        panel.add(vacc_id_lbl);

        vacc_id_textField_1 = new JTextField();
        vacc_id_textField_1.setColumns(10);
        vacc_id_textField_1.setBounds(139, 80, 184, 27);
        panel.add(vacc_id_textField_1);

        vacc_ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        vacc_ERRor_lbl.setForeground(Color.RED);
        vacc_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        vacc_ERRor_lbl.setBounds(345, 79, 199, 27);
        panel.add(vacc_ERRor_lbl);

        vacc_price_lbl = new JLabel("Price");
        vacc_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        vacc_price_lbl.setBounds(10, 117, 119, 27);
        panel.add(vacc_price_lbl);

        price_textField_2 = new JTextField();
        price_textField_2.setColumns(10);
        price_textField_2.setBounds(139, 118, 184, 27);
        panel.add(price_textField_2);

        price_ERRor_lbl = new JLabel("DIGITS ONLY");
        price_ERRor_lbl.setForeground(Color.RED);
        price_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        price_ERRor_lbl.setBounds(345, 117, 199, 27);
        panel.add(price_ERRor_lbl);

        vacc_name_lbl = new JLabel("Name");
        vacc_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        vacc_name_lbl.setBounds(10, 155, 119, 27);
        panel.add(vacc_name_lbl);

        String vaccString[]= {"synovac","immuner","s gram","anti allergic"};
        comboBox = new JComboBox(vaccString);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
        comboBox.setBounds(139, 158, 184, 27);
        panel.add(comboBox);

        stock_id__ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        stock_id__ERRor_lbl.setForeground(Color.RED);
        stock_id__ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        stock_id__ERRor_lbl.setBounds(345, 193, 199, 27);
        panel.add(stock_id__ERRor_lbl);

        textField = new JTextField();
        textField.setColumns(10);
        textField.setBounds(139, 197, 184, 27);
        panel.add(textField);

        stock_id_lbl = new JLabel("Stock ID");
        stock_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        stock_id_lbl.setBounds(10, 193, 119, 27);
        panel.add(stock_id_lbl);

        supplier_name_lbl = new JLabel("Supplier name");
        supplier_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        supplier_name_lbl.setBounds(10, 234, 119, 27);
        panel.add(supplier_name_lbl);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(138, 235, 184, 27);
        panel.add(textField_1);

        suppliername_ERRor_lbl = new JLabel("APLHABETS ONLY");
        suppliername_ERRor_lbl.setForeground(Color.RED);
        suppliername_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        suppliername_ERRor_lbl.setBounds(345, 241, 199, 27);
        panel.add(suppliername_ERRor_lbl);

//        pet_added_msg_lbl = new JLabel("Employee Added");
//        pet_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
//        pet_added_msg_lbl.setForeground(Color.RED);
//        pet_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
//        pet_added_msg_lbl.setBounds(183, 259, 199, 27);
//        panel.add(pet_added_msg_lbl);

        add_btn = new JButton("ADD");
        add_btn.setForeground(Color.WHITE);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setBackground(Color.GRAY);
        add_btn.setBounds(166, 288, 133, 35);
        panel.add(add_btn);
        add_btn.addActionListener(a1);
        productIDtextField.setText(products.generateProductID());
        vacc_id_textField_1.setText(productIDtextField.getText());
        productIDtextField.setEditable(false);
        vacc_id_textField_1.setEditable(false);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn))
            {
                if (a.getSource().equals(add_btn))
                {
                    boolean valid=true;
                    if (!customers.isdigitOnly(price_textField_2.getText()))
                    {
//                        System.out.println("price error");
                        valid=false;

                    }
                    if (!customers.isdigitOnly(textField.getText()))
                    {
                        valid=false;
//                        System.out.println("id error");
                    }

                    if (!customers.isStringOnlyAlphabet(textField_1.getText()))
                    {
                        valid=false;
//                        System.out.println("supplier error");
                    }
                    if (!valid);
                    else
                    {
                        System.out.println("inserting");
                        if (!stocks.newStock(textField.getText()))
                        {
                            textField_1.setText(stocks.stock_supplier_name(textField.getText()));
                        }
                        else {
                            stocks.addnewStock(textField.getText(),textField_1.getText());
                        }
                        products.addProducts(productIDtextField.getText(),"vaccination",textField.getText());
                        vaccination.addVaccine(productIDtextField.getText(),vacc_id_textField_1.getText(),
                                String.valueOf(comboBox.getSelectedItem()),price_textField_2.getText());
                        setVisible(false);

                        JOptionPane.showMessageDialog(null, "added");
                        new add_vacc_panel().setVisible(true);

                    }

                }

            }

        }
    }

}