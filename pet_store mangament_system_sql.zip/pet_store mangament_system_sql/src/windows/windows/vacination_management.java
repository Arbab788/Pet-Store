package windows;

import backend.products;
import backend.vaccination;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class vacination_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_vaccination_btn;
    private JButton view_vaccination_btn;
    private JButton update_vaccination_btn;
    private JButton products_manag_btn;
    private JButton delete_vaccination_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton search_vaccination_btn_1;

    public vacination_management() {
        initialize();

    }

    private void initialize() {
        ActionListener a1 = new actionListener();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_vaccination_btn = new JButton("ADD VACCINATION");
        add_vaccination_btn.setForeground(new Color(0, 0, 0));
        add_vaccination_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_vaccination_btn.setBackground(SystemColor.info);
        add_vaccination_btn.setBounds(29, 25, 167, 42);
        panel.add(add_vaccination_btn);
        add_vaccination_btn.addActionListener(a1);

        view_vaccination_btn = new JButton("VIEW VACCINATION");
        view_vaccination_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        view_vaccination_btn.setBackground(SystemColor.info);
        view_vaccination_btn.addActionListener(a1);

        view_vaccination_btn.setBounds(206, 25, 184, 42);
        panel.add(view_vaccination_btn);

        update_vaccination_btn = new JButton("UPDATE VACCINATION");
        update_vaccination_btn.setBackground(SystemColor.info);
        update_vaccination_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_vaccination_btn.setBounds(400, 25, 186, 42);
        panel.add(update_vaccination_btn);
        update_vaccination_btn.addActionListener(a1);

        products_manag_btn = new JButton("Products management");
        products_manag_btn.setBackground(SystemColor.info);
        products_manag_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        products_manag_btn.setBounds(29, 89, 207, 33);
        panel.add(products_manag_btn);
        products_manag_btn.addActionListener(a1);

        delete_vaccination_btn = new JButton("DELETE VACCINATION");
        delete_vaccination_btn.setForeground(Color.BLACK);
        delete_vaccination_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        delete_vaccination_btn.setBackground(SystemColor.info);
        delete_vaccination_btn.setBounds(596, 25, 178, 42);
        panel.add(delete_vaccination_btn);
        delete_vaccination_btn.addActionListener(a1);

        textFiled = new JTextArea();
        textFiled.setWrapStyleWord(true);
        textFiled.setBounds(141, 238, 561, 83);

        panel.add(textFiled);
        scroll = new JScrollPane(textFiled);
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        search_vaccination_btn_1 = new JButton("SEARCH VACCINATION");
        search_vaccination_btn_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        search_vaccination_btn_1.setBackground(SystemColor.info);
        search_vaccination_btn_1.setBounds(596, 84, 178, 42);
        panel.add(search_vaccination_btn_1);
        search_vaccination_btn_1.addActionListener(a1);
    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_vaccination_btn)) {

                add_vacc_panel av = new add_vacc_panel();
                av.setVisible(true);
                System.out.println("add panel");
            } else if (a.getSource().equals(view_vaccination_btn)) {
                Connection connection;
                scroll.setVisible(true);
                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select *" +
                            " from vaccination");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][]{
                            },
                            new String[]{
                                    "VACCINATION ID ", "PRICE", "NAME"
                            }
                    ) {
                        Class[] columnTypes = new Class[]{
                                String.class, String.class, String.class
                        };

                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }

                        boolean[] columnEditables = new boolean[]{
                                false, false, false
                        };

                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel = (DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[] = {rs.getString(2), rs.getString(3),
                                rs.getString(4)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }

//                String s = "ProdID\t\t\tVaccID\t\t\tPrice\t\t\tName\n" + "-------------------" +
//                        "--------------------------------------" +
//                        "-------" +
//                        "--------------------------------------------------------------------------" +
//                        "--\n\n";
//                scroll.setVisible(true);
//                textFiled.setText(s + vaccination.viewvaccination());
//                textFiled.setEditable(false);
//                scroll.isEnabled();
//                textFiled.setFont(new Font("Tahoma", Font.BOLD, 13));

            } else if (a.getSource().equals(update_vaccination_btn)) {
                String vacc_id = JOptionPane.showInputDialog("enter vaccination food ID you want to update");
                if (vaccination.searchVacc(vacc_id)) {
                    update_vacc_panel vv = new update_vacc_panel(vacc_id);
                    vv.setVisible(true);

                } else {
                    JOptionPane.showMessageDialog(null, "no such vaccination id found");

                }
            } else if (a.getSource().equals(delete_vaccination_btn)) {
                String vacc_id = JOptionPane.showInputDialog("enter pet vaccination ID you want to Delete");
                if (vaccination.searchVacc(vacc_id)) {
                    products.delete_products(vacc_id);
                    JOptionPane.showMessageDialog(null, " vaccination record deleted");

                } else {
                    JOptionPane.showMessageDialog(null, "no such id found");

                }

            } else if (a.getSource().equals(search_vaccination_btn_1)) {
                String vacc_id = JOptionPane.showInputDialog("enter pet vaccination name you want to Search");
                if (vaccination.searchVacc(vacc_id)) {

                    Connection connection;
                    scroll.setVisible(true);
                    try {
                        connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                        PreparedStatement queryStatement = connection.prepareStatement("select *" +
                                " from vaccination where vaccination_id=?");
                        queryStatement.setString(1,vacc_id);
                        ResultSet rs = queryStatement.executeQuery();
                        JTable table = new JTable();
                        table.setModel(new DefaultTableModel(
                                new Object[][]{
                                },
                                new String[]{
                                        "VACCINATION ID ", "PRICE", "NAME"
                                }
                        ) {
                            Class[] columnTypes = new Class[]{
                                    String.class, String.class, String.class
                            };

                            public Class getColumnClass(int columnIndex) {
                                return columnTypes[columnIndex];
                            }

                            boolean[] columnEditables = new boolean[]{
                                    false, false, false
                            };

                            public boolean isCellEditable(int row, int column) {
                                return columnEditables[column];
                            }
                        });
                        scroll.setViewportView(table);
                        DefaultTableModel tbModel = (DefaultTableModel) table.getModel();

                        while (rs.next()) {
                            String tbData[] = {rs.getString(2), rs.getString(3),
                                    rs.getString(4)};
                            tbModel.addRow(tbData);

                        }

                    } catch (Exception e) {
                        System.out.println(e);
                    }



                } else {
                    JOptionPane.showMessageDialog(null, "no such id found");

                }
            } else if (a.getSource().equals(products_manag_btn)) {
                products_management p1 = new products_management();
                p1.setVisible(true);
                dispose();
            }
        }
    }
}