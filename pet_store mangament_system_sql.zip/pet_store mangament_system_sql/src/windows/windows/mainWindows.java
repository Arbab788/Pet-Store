package windows;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

public class mainWindows extends JFrame {

    Connection connection;

    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {
            public void run() {

                try {
                    signin frame = new signin();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


}
