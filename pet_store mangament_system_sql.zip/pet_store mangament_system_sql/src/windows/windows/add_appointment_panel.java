package windows;


import backend.appointments;
import backend.customers;
import backend.pet_doctors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_appointment_panel extends JDialog {

    private JPanel contentPane;
    private JLabel appoint_id_lbl;
    private JLabel pet_type_lbl;
    private JPanel panel;
    private JLabel date_lbl;
    private JTextField appoint_id_textField;
    private JTextField date_textField_2;
    private JTextField doc_id_textField;
    private JButton add_appt_btn;
    private JComboBox comboBox;
    private JLabel fees_error_lbl_1_2;

    public add_appointment_panel() {
        initialize();
    }

    private void initialize() {

        setBounds(100, 100, 662, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 646, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        appoint_id_lbl = new JLabel("Appointment ID");
        appoint_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        appoint_id_lbl.setBounds(10, 110, 131, 33);
        panel.add(appoint_id_lbl);

        pet_type_lbl = new JLabel("Pet Type");
        pet_type_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        pet_type_lbl.setBounds(10, 180, 131, 33);
        panel.add(pet_type_lbl);

        date_lbl = new JLabel("Date");
        date_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        date_lbl.setBounds(10, 251, 131, 33);
        panel.add(date_lbl);

        appoint_id_textField = new JTextField();
        appoint_id_textField.setBounds(151, 110, 221, 33);
        panel.add(appoint_id_textField);
        appoint_id_textField.setColumns(10);

        date_textField_2 = new JTextField();
        date_textField_2.setColumns(10);
        date_textField_2.setBounds(151, 251, 221, 33);
        panel.add(date_textField_2);

        doc_id_textField = new JTextField();
        doc_id_textField.setColumns(10);
        doc_id_textField.setBounds(151, 319, 221, 33);
        panel.add(doc_id_textField);

        JLabel doctor_id_lbl_1 = new JLabel("DOCTOR ID");
        doctor_id_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        doctor_id_lbl_1.setBounds(10, 319, 131, 33);
        panel.add(doctor_id_lbl_1);

        add_appt_btn = new JButton("ADD");
        add_appt_btn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        add_appt_btn.setBackground(Color.WHITE);
        add_appt_btn.setForeground(Color.DARK_GRAY);
        add_appt_btn.setBounds(172, 390, 162, 35);
        panel.add(add_appt_btn);

         fees_error_lbl_1_2 = new JLabel("digits only");
        fees_error_lbl_1_2.setHorizontalAlignment(SwingConstants.CENTER);
        fees_error_lbl_1_2.setForeground(Color.RED);
        fees_error_lbl_1_2.setFont(new Font("Tahoma", Font.ITALIC, 13));
        fees_error_lbl_1_2.setBounds(399, 319, 237, 33);
        panel.add(fees_error_lbl_1_2);
        String pets[] = {"Dog", "cat", "goat", "rabbit", "parrot"};
        comboBox = new JComboBox(pets);
        comboBox.setBounds(151, 187, 221, 26);
        panel.add(comboBox);
        ActionListener a1 = new actionListener();
        add_appt_btn.addActionListener(a1);
        appoint_id_textField.setText(appointments.generate_appt_ID());
        appoint_id_textField.setEditable(false);
        date_textField_2.setText(String.valueOf(java.time.LocalDate.now()));
        date_textField_2.setEditable(false);
        fees_error_lbl_1_2.setVisible(false);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_appt_btn)) {
                if (customers.isdigitOnly(doc_id_textField.getText())) {
                    if (pet_doctors.search_doctors(doc_id_textField.getText())) {
                        appointments.add_appt(appoint_id_textField.getText(), String.valueOf(comboBox.getSelectedItem()),
                                date_textField_2.getText(), doc_id_textField.getText());
                        JOptionPane.showMessageDialog(null,"added ");
                        setVisible(false);
                        new add_appointment_panel().setVisible(true);
                    }
                    else {
                        JOptionPane.showMessageDialog(null,"no such doctor id found");
                    }
                }
                else
                {
                 fees_error_lbl_1_2.setVisible(true);
                }

            }
        }
    }

}
