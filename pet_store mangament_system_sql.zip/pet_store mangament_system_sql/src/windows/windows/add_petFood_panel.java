package windows;

import backend.customers;
import backend.pet_food;
import backend.products;
import backend.stocks;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_petFood_panel extends JDialog{

    private JPanel contentPane;

    private JPanel panel;
    private JButton add_btn;
    private JLabel pet_added_msg_lbl;
    private JLabel Product_id_lbl;
    private JTextField prod_idtextField_2;
    private JLabel productID_ERRor_lbl;
    private JLabel food_id_ERRor_lbl;
    private JTextField foodID_textField_3;
    private JLabel food_id_lbl;
    private JLabel food_price_lbl;
    private JTextField price_textField_4;
    private JLabel price_ERRor_lbl;
    private JComboBox comboBox;
    private JLabel weight_lbl;
    private JTextField supplier_nametextField;
    private JLabel stock_id_lbl;
    private JLabel supplier_name_lbl;
    private JTextField stock_IDtextField_1;
    private JLabel stock_id__ERRor_lbl;
    private JLabel suppliername_ERRor_lbl;
    private JLabel food_name_lbl_1;
    private JLabel foodname_ERRor_lbl_1;
    private JComboBox foodname_comboBox_1;

    public add_petFood_panel() {
        initialize();

    }
    private void initialize(){
        ActionListener a1=new actionListener();
        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        add_btn = new JButton("ADD");
        add_btn.setBackground(Color.GRAY);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setForeground(Color.WHITE);
        add_btn.setBounds(166, 315, 133, 35);
        panel.add(add_btn);

        pet_added_msg_lbl = new JLabel("");
        pet_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
        pet_added_msg_lbl.setForeground(Color.RED);
        pet_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        pet_added_msg_lbl.setBounds(181, 279, 199, 27);
        panel.add(pet_added_msg_lbl);

        String s1[]= {"1","2","3","4","5","10","20"};

        Product_id_lbl = new JLabel("PROUCT ID");
        Product_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        Product_id_lbl.setBounds(10, 11, 119, 27);
        panel.add(Product_id_lbl);

        prod_idtextField_2 = new JTextField();
        prod_idtextField_2.setColumns(10);
        prod_idtextField_2.setBounds(139, 12, 184, 27);
        panel.add(prod_idtextField_2);

        productID_ERRor_lbl = new JLabel("DIGITS ONLY(max 37 digits)");
        productID_ERRor_lbl.setForeground(Color.RED);
        productID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        productID_ERRor_lbl.setBounds(345, 11, 199, 27);
        panel.add(productID_ERRor_lbl);

        food_id_ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        food_id_ERRor_lbl.setForeground(Color.RED);
        food_id_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        food_id_ERRor_lbl.setBounds(345, 53, 199, 27);
        panel.add(food_id_ERRor_lbl);

        foodID_textField_3 = new JTextField();
        foodID_textField_3.setColumns(10);
        foodID_textField_3.setBounds(139, 54, 184, 27);
        panel.add(foodID_textField_3);

        food_id_lbl = new JLabel("FOOD ID");
        food_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        food_id_lbl.setBounds(10, 53, 119, 27);
        panel.add(food_id_lbl);

        food_price_lbl = new JLabel("PRICE");
        food_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        food_price_lbl.setBounds(10, 91, 119, 27);
        panel.add(food_price_lbl);

        price_textField_4 = new JTextField();
        price_textField_4.setColumns(10);
        price_textField_4.setBounds(139, 92, 184, 27);
        panel.add(price_textField_4);

        price_ERRor_lbl = new JLabel("DIGITS ONLY");
        price_ERRor_lbl.setForeground(Color.RED);
        price_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        price_ERRor_lbl.setBounds(345, 91, 199, 27);
        panel.add(price_ERRor_lbl);

        String s11[]= {"1","2","3","4","5","10","20"};
        comboBox = new JComboBox(s11);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
        comboBox.setBounds(139, 130, 184, 27);
        panel.add(comboBox);

        weight_lbl = new JLabel("WEIGHT (kg )");
        weight_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        weight_lbl.setBounds(10, 129, 119, 27);
        panel.add(weight_lbl);

        supplier_nametextField = new JTextField();
        supplier_nametextField.setColumns(10);
        supplier_nametextField.setBounds(138, 248, 184, 27);
        panel.add(supplier_nametextField);

        stock_id_lbl = new JLabel("Stock ID");
        stock_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        stock_id_lbl.setBounds(10, 206, 119, 27);
        panel.add(stock_id_lbl);

        supplier_name_lbl = new JLabel("Supplier name");
        supplier_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        supplier_name_lbl.setBounds(10, 247, 119, 27);
        panel.add(supplier_name_lbl);

        stock_IDtextField_1 = new JTextField();
        stock_IDtextField_1.setColumns(10);
        stock_IDtextField_1.setBounds(139, 210, 184, 27);
        panel.add(stock_IDtextField_1);

        stock_id__ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        stock_id__ERRor_lbl.setForeground(Color.RED);
        stock_id__ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        stock_id__ERRor_lbl.setBounds(345, 206, 199, 27);
        panel.add(stock_id__ERRor_lbl);

        suppliername_ERRor_lbl = new JLabel("APLHABETS ONLY");
        suppliername_ERRor_lbl.setForeground(Color.RED);
        suppliername_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        suppliername_ERRor_lbl.setBounds(345, 254, 199, 27);
        panel.add(suppliername_ERRor_lbl);

        food_name_lbl_1 = new JLabel("Food name");
        food_name_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        food_name_lbl_1.setBounds(10, 168, 119, 27);
        panel.add(food_name_lbl_1);

        foodname_ERRor_lbl_1 = new JLabel("APLHABETS ONLY");
        foodname_ERRor_lbl_1.setForeground(Color.RED);
        foodname_ERRor_lbl_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        foodname_ERRor_lbl_1.setBounds(345, 175, 199, 27);
        panel.add(foodname_ERRor_lbl_1);

        String s[]={"meetballs","biscuits","milk","bones"};
        foodname_comboBox_1 = new JComboBox(s);
        foodname_comboBox_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        foodname_comboBox_1.setBounds(139, 172, 184, 27);
        panel.add(foodname_comboBox_1);
        add_btn.addActionListener(a1);
        prod_idtextField_2.setText(products.generateProductID());
        prod_idtextField_2.setEditable(false);
        foodID_textField_3.setText(prod_idtextField_2.getText());
        foodID_textField_3.setEditable(false);


    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn))
            {
                boolean valid=true;
                pet_added_msg_lbl.setVisible(true);
                if(!customers.isdigitOnly(price_textField_4.getText()))
                {
                    valid=false;
//                    System.out.println("price eerrr");
                }
                if (!customers.isStringOnlyAlphabet(supplier_nametextField.getText()))
                {
                    valid=false;
//                    System.out.println("stock name error");
                }
                if (!customers.isdigitOnly(stock_IDtextField_1.getText()))
                {
                    valid=false;
//                    System.out.println("invalid stock id");
                }
                if (!valid);
                else
                {
                    if (!stocks.newStock(stock_IDtextField_1.getText()))
                    {
                        supplier_nametextField.setText(stocks.stock_supplier_name(stock_IDtextField_1.getText()));
                    }
                    else
                    {
                        stocks.addnewStock(stock_IDtextField_1.getText(),supplier_nametextField.getText());
                    }
                    products.addProducts(prod_idtextField_2.getText(),"pet_food",stock_IDtextField_1.getText());
                    pet_food.addPet_food(prod_idtextField_2.getText(),foodID_textField_3.getText(),
                            String.valueOf(comboBox.getSelectedItem()),String.valueOf(foodname_comboBox_1.getSelectedItem()),
                            price_textField_4.getText());
                    setVisible(false);
                    JOptionPane.showMessageDialog(null,"added");
                    new add_petFood_panel().setVisible(true);


                }
            }

        }
    }

}