package windows;

import backend.customers;
import backend.orders;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class orders_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_order;
    private JButton view_order_btn;
    private JButton deleteOrder_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton homepage_btn;


    public orders_management() {
        initialize();


    }
    private void initialize(){
        ActionListener a1=new actionListener();


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_order = new JButton("ADD ORDER");
        add_order.setBackground(SystemColor.info);
        add_order.setBounds(29, 25, 142, 51);
        panel.add(add_order);


        view_order_btn = new JButton("VIEW Orders");
        view_order_btn.setBackground(SystemColor.info);

        view_order_btn.setBounds(327, 25, 142, 51);
        panel.add(view_order_btn);

        deleteOrder_btn = new JButton("DELETE Oder");
        deleteOrder_btn.setBounds(590, 25, 142, 51);
        panel.add(deleteOrder_btn);
        deleteOrder_btn.setBackground(SystemColor.info);

        textFiled = new JTextArea();
        textFiled.setWrapStyleWord(true);
        textFiled.setBounds(141, 238, 561, 83);
        textFiled.setEditable(false);

        panel.add(textFiled);
        scroll = new JScrollPane();
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        homepage_btn = new JButton("Sales management");
        homepage_btn.setBounds(39, 94, 160, 23);
        homepage_btn.setBackground(SystemColor.info);
        panel.add(homepage_btn);

        add_order.addActionListener(a1);
        view_order_btn.addActionListener(a1);
        deleteOrder_btn.addActionListener(a1);
        homepage_btn.addActionListener(a1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_order))
            {
                addorder a1=new addorder();
                a1.setVisible(true);


            }
            else if (a.getSource().equals(view_order_btn))
            {
                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select * from " +
                            " orders");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();

                    table.setModel(new DefaultTableModel(
                            new Object[][] {
                            },
                            new String[] {
                                    "orderID", "orderDate","CustomerID","CUSTOMER NAME","ProdID"
                            }
                    ) {
                        Class[] columnTypes = new Class[] {
                                String.class, String.class,String.class,String.class,String.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                        boolean[] columnEditables = new boolean[] {
                                false, false,false,false,false
                        };
                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[]={rs.getString(1),rs.getString(2),rs.getString(3),
                                customers.custoemr_name(rs.getString(3)),rs.getString(4)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }

            }
            else if (a.getSource().equals(deleteOrder_btn))
            {
                String o_id = JOptionPane.showInputDialog("enter order id you want ot delete");
                if (orders.searchorder(o_id) )
                {
                    orders.delete_order(o_id);

                    JOptionPane.showMessageDialog(null, "deleted successfully");
                }
                else
                    JOptionPane.showMessageDialog(null,"no such order found");

            }
            else if (a.getSource().equals(homepage_btn))
            {
                sales_management s1=new sales_management();
                s1.setVisible(true);
                dispose();
            }

        }
    }
}