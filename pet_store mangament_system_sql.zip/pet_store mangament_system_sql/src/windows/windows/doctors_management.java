package windows;

import backend.pet_doctors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class doctors_management extends JFrame {

    private JPanel contentPane;
    private JButton add_doctor_btn;
    private JButton view_doctor_btn;
    private JButton delete_doctors_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton homepage_btn;
    private JButton update_doctors_btn;
    private JPanel panel;

    public doctors_management() {
        initialize();
    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);


        add_doctor_btn = new JButton("ADD DOCTOR");
        add_doctor_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_doctor_btn.setBackground(SystemColor.info);
        add_doctor_btn.setBounds(29, 25, 142, 51);
        panel.add(add_doctor_btn);

        view_doctor_btn = new JButton("VIEW DOCTORS");
        view_doctor_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        view_doctor_btn.setBackground(SystemColor.info);

        view_doctor_btn.setBounds(207, 25, 142, 51);
        panel.add(view_doctor_btn);

        delete_doctors_btn = new JButton("DELETE DOCTORS");
        delete_doctors_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        delete_doctors_btn.setBounds(590, 25, 142, 51);
        panel.add(delete_doctors_btn);
        delete_doctors_btn.setBackground(SystemColor.info);

//        textFiled = new JTextArea();
//        textFiled.setWrapStyleWord(true);
//        textFiled.setBounds(10, 0, 561, 83);

//        panel.add(textFiled);
        scroll = new JScrollPane();
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        homepage_btn = new JButton("BACK");
        homepage_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        homepage_btn.setBounds(29, 87, 142, 30);
        panel.add(homepage_btn);
        homepage_btn.setBackground(SystemColor.info);

        update_doctors_btn = new JButton("UPDATE DOCTORS");
        update_doctors_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_doctors_btn.setBackground(SystemColor.info);
        update_doctors_btn.setBounds(380, 25, 170, 51);
        panel.add(update_doctors_btn);
        ActionListener a1=new actionListener();
        add_doctor_btn.addActionListener(a1);
        view_doctor_btn.addActionListener(a1);
        update_doctors_btn.addActionListener(a1);
        delete_doctors_btn.addActionListener(a1);
        homepage_btn.addActionListener(a1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_doctor_btn))
            {
                add_doctors_panel d=new add_doctors_panel();
                d.setVisible(true);

            }
            else if (a.getSource().equals(view_doctor_btn))
            {

                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select * " +
                            " from pet_doctors");
                    ResultSet rs = queryStatement.executeQuery();
                   JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][] {
                            },
                            new String[] {
                                    "ID ", "FIRST NAME","LAST NAME","FEES"
                            }
                    ) {
                        Class[] columnTypes = new Class[] {
                                String.class, String.class,String.class,String.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                        boolean[] columnEditables = new boolean[] {
                                false, false,false,false
                        };
                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[]={rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }
//
//                String s="DocID\t\t\tFname_ID\t\t\tL_name\t\t\tFees\n"+"-------------------" +
//                        "--------------------------------------" +
//                        "----------------------------------------------------------------------------" +
//                        "----------------------------------------------------------------------" +
//                        "--\n\n";
//                scroll.setVisible(true);
//                textFiled.setText(s+ pet_doctors.view_doctors());
//                textFiled.setEditable(false);
//                scroll.isEnabled();
//                textFiled.setFont(new Font("Tahoma", Font.BOLD, 13));
            }
            else if(a.getSource().equals(update_doctors_btn))
            {
                String doc_id=JOptionPane.showInputDialog("enter doctor ID you want to update");
                if(pet_doctors.search_doctors(doc_id)){
                    update__docotors_panel ud=new update__docotors_panel(doc_id);
                    ud.setVisible(true);

                }
                else
                {
                    JOptionPane.showMessageDialog(null,"no such doctor id found");

                }

            }
            else if (a.getSource().equals(delete_doctors_btn))
            {
                String doc_id=JOptionPane.showInputDialog("enter doctor ID you want to delete");
                if(pet_doctors.search_doctors(doc_id)){
                    pet_doctors.delete_doctors(doc_id);
                    JOptionPane.showMessageDialog(null,"deleted successfully");
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"no such doctor id found");

                }

            }
            else if (a.getSource().equals(homepage_btn))
            {
                services_management s=new services_management();
                s.setVisible(true);
                dispose();
            }

        }
    }
}
