package windows;

import backend.accessories;
import backend.customers;
import backend.products;
import backend.stocks;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_accessories_panel extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_btn;
    private JLabel Product_id_lbl;
    private JTextField productIDtextField;
    private JLabel productID_ERRor_lbl;
    private JLabel accessories_id_lbl;
    private JTextField accessiories_id_textField_1;
    private JLabel accessiories_id_ERRor_lbl;
    private JLabel accessiories_price_lbl;
    private JTextField accessiories_price_textField_2;
    private JLabel accessiories_ERRor_lbl;
    private JLabel accessiories_name_lbl;
    private JLabel accessory_added_msg_lbl;
    private JLabel supplier_name_lbl;
    private JLabel stock_id_lbl;
    private JTextField textField;
    private JLabel supplier_name_lbl_1;
    private JTextField textField_1;
    private JLabel suppliername_ERRor_lbl;
    private JLabel stock_id__ERRor_lbl;
    private JComboBox comboBox;

    public add_accessories_panel() {
        ActionListener a1=new actionListener();
        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        add_btn = new JButton("ADD");
        add_btn.setBackground(Color.GRAY);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setForeground(Color.WHITE);
        add_btn.setBounds(166, 326, 133, 35);
        panel.add(add_btn);

        Product_id_lbl = new JLabel("PROUCT ID");
        Product_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        Product_id_lbl.setBounds(10, 37, 119, 27);
        panel.add(Product_id_lbl);

        productIDtextField = new JTextField();
        productIDtextField.setColumns(10);
        productIDtextField.setBounds(139, 38, 184, 27);
        panel.add(productIDtextField);

        productID_ERRor_lbl = new JLabel("DIGITS ONLY(max 37 digits)");
        productID_ERRor_lbl.setForeground(Color.RED);
        productID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        productID_ERRor_lbl.setBounds(345, 37, 199, 27);
        panel.add(productID_ERRor_lbl);

        accessories_id_lbl = new JLabel("Accessories ID");
        accessories_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        accessories_id_lbl.setBounds(10, 79, 119, 27);
        panel.add(accessories_id_lbl);

        accessiories_id_textField_1 = new JTextField();
        accessiories_id_textField_1.setColumns(10);
        accessiories_id_textField_1.setBounds(139, 80, 184, 27);
        panel.add(accessiories_id_textField_1);

        accessiories_id_ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        accessiories_id_ERRor_lbl.setForeground(Color.RED);
        accessiories_id_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        accessiories_id_ERRor_lbl.setBounds(345, 79, 199, 27);
        panel.add(accessiories_id_ERRor_lbl);

        accessiories_price_lbl = new JLabel("PRICE");
        accessiories_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        accessiories_price_lbl.setBounds(10, 117, 119, 27);
        panel.add(accessiories_price_lbl);

        accessiories_price_textField_2 = new JTextField();
        accessiories_price_textField_2.setColumns(10);
        accessiories_price_textField_2.setBounds(139, 118, 184, 27);
        panel.add(accessiories_price_textField_2);

        accessiories_ERRor_lbl = new JLabel("DIGITS ONLY");
        accessiories_ERRor_lbl.setForeground(Color.RED);
        accessiories_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        accessiories_ERRor_lbl.setBounds(345, 117, 199, 27);
        panel.add(accessiories_ERRor_lbl);

        accessiories_name_lbl = new JLabel("NAME");
        accessiories_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        accessiories_name_lbl.setBounds(10, 155, 119, 27);
        panel.add(accessiories_name_lbl);

        accessory_added_msg_lbl = new JLabel("Accessory Added");
        accessory_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
        accessory_added_msg_lbl.setForeground(Color.RED);
        accessory_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        accessory_added_msg_lbl.setBounds(183, 297, 199, 27);
        panel.add(accessory_added_msg_lbl);


        stock_id_lbl = new JLabel("Stock ID");
        stock_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        stock_id_lbl.setBounds(10, 193, 119, 27);
        panel.add(stock_id_lbl);

        textField = new JTextField();

        textField.setColumns(10);
        textField.setBounds(139, 197, 184, 27);
        panel.add(textField);

        supplier_name_lbl_1 = new JLabel("Supplier name");
        supplier_name_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        supplier_name_lbl_1.setBounds(10, 231, 119, 27);
        panel.add(supplier_name_lbl_1);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(138, 232, 184, 27);
        panel.add(textField_1);

        suppliername_ERRor_lbl = new JLabel("APLHABETS ONLY");
        suppliername_ERRor_lbl.setForeground(Color.RED);
        suppliername_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        suppliername_ERRor_lbl.setBounds(345, 238, 199, 27);
        panel.add(suppliername_ERRor_lbl);

        stock_id__ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        stock_id__ERRor_lbl.setForeground(Color.RED);
        stock_id__ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        stock_id__ERRor_lbl.setBounds(345, 193, 199, 27);
        panel.add(stock_id__ERRor_lbl);

        String accessorieis[]={"collar","rope","chain","playball","form shampoo","food bowl"};
        comboBox = new JComboBox(accessorieis);
        comboBox.setBounds(139, 156, 184, 26);
        panel.add(comboBox);
        add_btn.addActionListener(a1);
        productIDtextField.setText(products.generateProductID());
        accessiories_id_textField_1.setText(productIDtextField.getText());
        accessiories_id_textField_1.setEditable(false);
        productIDtextField.setEditable(false);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn))
            {
//                System.out.println("add boutton brda");
                boolean valid=true;
                if (!customers.isdigitOnly(accessiories_price_textField_2.getText()))
                {
//                    System.out.println("price error");
                    valid=false;
                }
                if (!customers.isdigitOnly(textField.getText()))
                {
//                    System.out.println("stock id issue ");
                    valid=false;
                }
                if (!customers.isStringOnlyAlphabet(textField_1.getText()))
                {
//                    System.out.println("supplier name issue");
                    valid=false;
                }
                if (!valid);
                else
                {
                    boolean insertStock=false;
                    if (!stocks.newStock(textField.getText()))
                    {
                        insertStock=false;
                        textField_1.setText(stocks.stock_supplier_name(textField.getText()));
                    }
                    else
                    {
                        stocks.addnewStock(textField.getText(),textField_1.getText());
                    }
                    products.addProducts(productIDtextField.getText(),"accessories",textField.getText());
                    accessories.add_new_accessories(productIDtextField.getText(),accessiories_id_textField_1.getText(),
                            accessiories_price_textField_2.getText(),String.valueOf(comboBox.getSelectedItem()));
                    setVisible(false);

                    JOptionPane.showMessageDialog(null, "ADDED Successfully");
                    new add_accessories_panel().setVisible(true);

                }

            }

        }
    }

}