package windows;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class sales_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton customer_btn;
    private JButton receipts_btn;
    private JButton orders_btn;
    private JButton home_page_btn;

    public sales_management() {
        initialize();
    }
    private void initialize(){
        ActionListener a1=new actionListener();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        receipts_btn = new JButton("Receipts");
        receipts_btn.setBounds(298, 26, 173, 45);
        panel.add(receipts_btn);
        receipts_btn.addActionListener(a1);
        receipts_btn.setBackground(SystemColor.info);

        customer_btn = new JButton("Customers");
        customer_btn.setBounds(553, 26, 173, 45);
        panel.add(customer_btn);
        customer_btn.addActionListener(a1);
        customer_btn.setBackground(SystemColor.info);

        orders_btn = new JButton("Orders");
        orders_btn.setBounds(48, 26, 173, 45);
        panel.add(orders_btn);
        orders_btn.addActionListener(a1);
        orders_btn.setBackground(SystemColor.info);

        home_page_btn = new JButton("Homepage");
        home_page_btn.setBounds(48, 111, 165, 34);
        panel.add(home_page_btn);
        home_page_btn.addActionListener(a1);
        home_page_btn.setBackground(SystemColor.info);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(home_page_btn)){
                homePage h1=new homePage();
                h1.setVisible(true);
                dispose();
            }
            else if (a.getSource().equals(orders_btn))
            {
                orders_management o1=new orders_management();
                o1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(receipts_btn))
            {
                receipt_management r1=new receipt_management();
                r1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(customer_btn))
            {

                customer_managment c1=new customer_managment();
                c1.setVisible(true);
                dispose();

            }
        }
    }
}
