package windows;

import backend.admin;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class signin extends JFrame {

    private JPanel contentPane;
    private JTextField username_textField;
    private JPasswordField passwordField;
    private JLabel signinPanel;
    private JLabel password_lbl;
    private JLabel username_label;
    private Button signin_btn;
    private mainWindows frame;
    private JLabel error_labeel;
    Connection connection;
    private static admin a1;

    /**
     * Launch the application.
     */


    /**
     * Create the frame.
     */
    public signin() {
//        Connection connection;
        try {
            connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");

//            PreparedStatement queryStatement = connection.prepareStatement("select employee_id, first_name, last_name, salary from employees where salary > 2500");
////
//            ResultSet result = queryStatement.executeQuery();
//            System.out.println("ID\tFirst Name\tLast Name\tSalary");
//            while (result.next()) {
//                System.out.println(result.getString(1) + "\t" + result.getString(2) + "\t" + result.getString(3) + "\t" + result.getString(4));
//            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

//      this.frame=frame;
        initialize();

    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        Icon icon = new ImageIcon(signin.class.getResource("/resources/galaxy.jpg"));
        signinPanel = new JLabel();
        signinPanel.setIcon(icon);
        signinPanel.setBackground(new Color(179, 255, 58));
        signinPanel.setBounds(0, 0, 800, 500);
        contentPane.add(signinPanel);
        signinPanel.setLayout(null);

        username_label = new JLabel("USER NAME");
        username_label.setForeground(SystemColor.WHITE);
        username_label.setFont(new Font("Tahoma", Font.BOLD, 15));
        username_label.setBounds(77, 132, 122, 26);
        signinPanel.add(username_label);

        password_lbl = new JLabel("PASSWORD");
        password_lbl.setName("password_lbl");
        password_lbl.setForeground(SystemColor.WHITE);
        password_lbl.setFont(new Font("Tahoma", Font.BOLD, 15));
        password_lbl.setBounds(77, 171, 107, 26);
        signinPanel.add(password_lbl);

        username_textField = new JTextField("Arbab");
        username_textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        username_textField.setBounds(209, 129, 155, 29);
        signinPanel.add(username_textField);
        username_textField.setColumns(10);

        passwordField = new JPasswordField("1234567");
        passwordField.setBounds(209, 173, 155, 26);
        signinPanel.add(passwordField);


        actionListener a1 = new actionListener();
        signin_btn = new Button("SIGN IN");
        signin_btn.setFont(new Font("Tahoma", Font.PLAIN, 15));
        signin_btn.setBounds(245, 243, 70, 22);
        signinPanel.add(signin_btn);
        signin_btn.addActionListener(a1);

        error_labeel = new JLabel("Error to be displayed here");
        error_labeel.setForeground(Color.RED);
        error_labeel.setFont(new Font("Tahoma", Font.BOLD, 12));
        error_labeel.setBounds(176, 210, 316, 26);
        signinPanel.add(error_labeel);
        error_labeel.setVisible(false);
        if (username_textField.getText().equals("ac"))
            passwordField.setEditable(false);
    }
    public static admin currentadm(){
        return a1;
    }

    class actionListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent a) {

            if (a.getSource().equals(signin_btn)) {

                if (admin.checkSignin(username_textField.getText(),String.valueOf(passwordField.getPassword())))
                {
                    a1=new admin(username_textField.getText(),String.valueOf(passwordField.getPassword()));

                    System.out.println("go to home page");
                    dispose();
                    homePage h1 = new homePage();
                    h1.setVisible(true);
                }
                else {
                    error_labeel.setText("invalid username of password");
                    error_labeel.setVisible(true);
                    username_textField.setText("");
                    passwordField.setText("");

                }
            }

        }
    }

}
