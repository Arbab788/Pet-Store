package windows;

import backend.admin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class updateuserPanel extends JDialog {

    private JPanel contentPane;
    private JLabel password_lbl;
    private JLabel confirmpassword_lbl;
    private JTextField old_paas_textField;
    private JPasswordField new_passwordField;
    private JPasswordField confirm_passwordField_1;
    private JLabel error_lable;
    private JButton create_user_btn;
    private JPanel panel;
    private String usrname;

    public updateuserPanel(String uname) {
        usrname = uname;
        initialize();
    }

    private void initialize() {
        setBounds(119, 11, 688, 483);
        getContentPane().setLayout(null);

        panel = new JPanel();
        panel.setBounds(0, 0, 672, 444);
        panel.setFont(new Font("Tahoma", Font.BOLD, 13));
        panel.setBackground(SystemColor.activeCaption);
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel old_password_lbl = new JLabel("OLD PASSWORD");
        old_password_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        old_password_lbl.setBounds(34, 105, 122, 33);
        panel.add(old_password_lbl);

        password_lbl = new JLabel("NEW PASSWORD");
        password_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        password_lbl.setBounds(34, 146, 142, 40);
        panel.add(password_lbl);

        confirmpassword_lbl = new JLabel("CONFIRM PASSWORD");
        confirmpassword_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        confirmpassword_lbl.setBounds(34, 198, 142, 40);
        panel.add(confirmpassword_lbl);

        old_paas_textField = new JTextField();
        old_paas_textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        old_paas_textField.setBounds(214, 107, 192, 30);
        panel.add(old_paas_textField);
        old_paas_textField.setColumns(10);

        new_passwordField = new JPasswordField();
        new_passwordField.setBounds(214, 152, 192, 30);
        panel.add(new_passwordField);

        confirm_passwordField_1 = new JPasswordField();
        confirm_passwordField_1.setBounds(214, 205, 192, 29);
        panel.add(confirm_passwordField_1);

        error_lable = new JLabel("error to be dislplayed here");
        error_lable.setForeground(new Color(204, 0, 0));
        error_lable.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
        error_lable.setBounds(215, 244, 386, 33);
        panel.add(error_lable);

        create_user_btn = new JButton("Create User");
        create_user_btn.setBounds(249, 288, 122, 40);
        panel.add(create_user_btn);
        ActionListener a1 = new actionListener();
        create_user_btn.addActionListener(a1);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(create_user_btn)) {
                boolean valid = true;
                if (!admin.passwordMatch(usrname, old_paas_textField.getText())) {
                    error_lable.setText("old password doesnt match");
                    error_lable.setVisible(true);
                    valid = false;
                }
                else if (!admin.validPassword(String.valueOf(new_passwordField.getPassword()))) {
                    error_lable.setText("password length should be greater than 6");
                    error_lable.setVisible(true);
                    valid = false;
                }
                else if (!String.valueOf(new_passwordField.getPassword()).equals(String.valueOf(confirm_passwordField_1.getPassword()))) {
                    valid = false;
                    error_lable.setText("enter confirm password doesn't match new password");
                    error_lable.setVisible(true);
                }
//                if (!valid) ;
                else {
                    admin.updateUser(String.valueOf(confirm_passwordField_1.getPassword()),usrname);
                    JOptionPane.showMessageDialog(null,"updated");
                    setVisible(false);
                }


            }

        }
    }
}
