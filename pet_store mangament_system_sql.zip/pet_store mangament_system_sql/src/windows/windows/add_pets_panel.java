package windows;

import backend.customers;
import backend.pets;
import backend.products;
import backend.stocks;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_pets_panel extends JDialog{

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_btn;
    private JLabel Product_id_lbl;
    private JTextField productIDtextField;
    private JLabel productID_ERRor_lbl;
    private JLabel pet_id_lbl;
    private JTextField pet_id_textField_1;
    private JLabel pet_id_ERRor_lbl;
    private JLabel pet_price_lbl;
    private JTextField price_textField_2;
    private JLabel price_ERRor_lbl;
    private JLabel pet_color_lbl;
    private JLabel petbreed_lbl;
    private JLabel stock_id_lbl;
    private JTextField stock_id_textField_5;
    private JLabel stock_id__ERRor_lbl;
    private JLabel pet_added_msg_lbl;
    private JComboBox comboBox;
    private JComboBox colors_comboBox_1;
    private JLabel supplier_name_lbl;
    private JTextField supplier_name_textField;
    private JLabel suppliername_ERRor_lbl_1;

    public add_pets_panel() {
        initialize();

    }

    private void initialize() {
        ActionListener a1=new actionListener();
        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        add_btn = new JButton("ADD");
        add_btn.setBackground(Color.GRAY);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setForeground(Color.WHITE);
        add_btn.setBounds(166, 326, 133, 35);
        panel.add(add_btn);

        Product_id_lbl = new JLabel("PROUCT ID");
        Product_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        Product_id_lbl.setBounds(10, 37, 119, 27);
        panel.add(Product_id_lbl);

        productIDtextField = new JTextField();
        productIDtextField.setColumns(10);
        productIDtextField.setBounds(139, 38, 184, 27);
        panel.add(productIDtextField);

        productID_ERRor_lbl = new JLabel("DIGITS ONLY(max 37 digits)");
        productID_ERRor_lbl.setForeground(Color.RED);
        productID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        productID_ERRor_lbl.setBounds(345, 37, 199, 27);
        panel.add(productID_ERRor_lbl);

        pet_id_lbl = new JLabel("PET ID");
        pet_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        pet_id_lbl.setBounds(10, 79, 119, 27);
        panel.add(pet_id_lbl);

        pet_id_textField_1 = new JTextField();
        pet_id_textField_1.setColumns(10);
        pet_id_textField_1.setBounds(139, 80, 184, 27);
        panel.add(pet_id_textField_1);

        pet_id_ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        pet_id_ERRor_lbl.setForeground(Color.RED);
        pet_id_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        pet_id_ERRor_lbl.setBounds(345, 79, 199, 27);
        panel.add(pet_id_ERRor_lbl);

        pet_price_lbl = new JLabel("PRICE");
        pet_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        pet_price_lbl.setBounds(10, 117, 119, 27);
        panel.add(pet_price_lbl);

        price_textField_2 = new JTextField();
        price_textField_2.setColumns(10);
        price_textField_2.setBounds(139, 118, 184, 27);
        panel.add(price_textField_2);

        price_ERRor_lbl = new JLabel("DIGITS ONLY");
        price_ERRor_lbl.setForeground(Color.RED);
        price_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        price_ERRor_lbl.setBounds(345, 117, 199, 27);
        panel.add(price_ERRor_lbl);

        pet_color_lbl = new JLabel("COLOR");
        pet_color_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        pet_color_lbl.setBounds(10, 155, 119, 27);
        panel.add(pet_color_lbl);

        petbreed_lbl = new JLabel("BREED");
        petbreed_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        petbreed_lbl.setBounds(10, 193, 119, 27);
        panel.add(petbreed_lbl);

        stock_id_lbl = new JLabel("Stock ID");
        stock_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        stock_id_lbl.setBounds(10, 231, 119, 27);
        panel.add(stock_id_lbl);

        stock_id_textField_5 = new JTextField();
        stock_id_textField_5.setColumns(10);
        stock_id_textField_5.setBounds(139, 235, 184, 27);
        panel.add(stock_id_textField_5);

        stock_id__ERRor_lbl = new JLabel("DIGITS ONLY( max 37 digits)");
        stock_id__ERRor_lbl.setForeground(Color.RED);
        stock_id__ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        stock_id__ERRor_lbl.setBounds(345, 231, 199, 27);
        panel.add(stock_id__ERRor_lbl);

//        pet_added_msg_lbl = new JLabel("Employee Added");
//        pet_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
//        pet_added_msg_lbl.setForeground(Color.RED);
//        pet_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
//        pet_added_msg_lbl.setBounds(183, 297, 199, 27);
//        panel.add(pet_added_msg_lbl);

        String s1[] = {"german", "pitbull", "pointer", "husky", "rot wiler"};
        comboBox = new JComboBox(s1);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
        comboBox.setBounds(139, 196, 184, 27);
        panel.add(comboBox);

        String colors[] = {"brown", "grey", "white", "off whiite"};
        colors_comboBox_1 = new JComboBox(colors);
        colors_comboBox_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        colors_comboBox_1.setBounds(139, 158, 184, 27);
        panel.add(colors_comboBox_1);

        supplier_name_lbl = new JLabel("Supplier name");
        supplier_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        supplier_name_lbl.setBounds(10, 272, 119, 27);
        panel.add(supplier_name_lbl);

        supplier_name_textField = new JTextField();
        supplier_name_textField.setColumns(10);
        supplier_name_textField.setBounds(139, 273, 184, 27);
        panel.add(supplier_name_textField);

        suppliername_ERRor_lbl_1 = new JLabel("APLHABETS ONLY");
        suppliername_ERRor_lbl_1.setForeground(Color.RED);
        suppliername_ERRor_lbl_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        suppliername_ERRor_lbl_1.setBounds(345, 279, 199, 27);
        panel.add(suppliername_ERRor_lbl_1);
        add_btn.addActionListener(a1);

        productIDtextField.setText(products.generateProductID());
        productIDtextField.setEditable(false);
        pet_id_textField_1.setText(productIDtextField.getText());
        pet_id_textField_1.setEditable(false);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn))
            {
                boolean valid=true;
                if (!customers.isdigitOnly(price_textField_2.getText()))
                {
//                    System.out.println("price issue");
                    valid=false;
                }
                if (!customers.isdigitOnly(stock_id_textField_5.getText()))
                {
//                    System.out.println("stock id issue ");
                    valid=false;
                }
                if (!customers.isStringOnlyAlphabet(supplier_name_textField.getText()))
                {
//                    System.out.println("supplier name issue");
                    valid=false;
                }
                if (!valid);
                else
                {
                    boolean insertStock=true;
                    boolean insertProduct=false;
                    boolean insertPet=false;
                    if (!stocks.newStock(stock_id_textField_5.getText()))
                    {
                        insertStock=false;
                        supplier_name_textField.setText(stocks.stock_supplier_name(stock_id_textField_5.getText()));
                    }
                    if (insertStock)
                    {
                        stocks.addnewStock(stock_id_textField_5.getText(),supplier_name_textField.getText());
                    }
                    products.addProducts(productIDtextField.getText(),"pet_products",stock_id_textField_5.getText());
                    pets.addPets(productIDtextField.getText(),pet_id_textField_1.getText(),price_textField_2.getText(),
                            String.valueOf(colors_comboBox_1.getSelectedItem()),String.valueOf(comboBox.getSelectedItem()));
                    JOptionPane.showMessageDialog(null,"added");
                    new add_petFood_panel().setVisible(true);

                }
            }

        }
    }
}