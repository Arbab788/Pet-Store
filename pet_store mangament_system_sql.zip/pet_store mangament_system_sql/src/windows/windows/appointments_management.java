package windows;

import backend.appointments;
import backend.pet_doctors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class appointments_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_appointment_btn;
    private JButton view_appointment_btn;
    private JButton delete_appointment_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton homepage_btn;


    public appointments_management() {
        initialize();
    }

    private void initialize() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_appointment_btn = new JButton("ADD Appointment");
        add_appointment_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_appointment_btn.setBackground(SystemColor.info);
        add_appointment_btn.setBounds(29, 25, 192, 51);
        panel.add(add_appointment_btn);

        view_appointment_btn = new JButton("VIEW Appointment");
        view_appointment_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        view_appointment_btn.setBackground(SystemColor.info);

        view_appointment_btn.setBounds(277, 25, 192, 51);
        panel.add(view_appointment_btn);

        delete_appointment_btn = new JButton("DELETE Appointment");
        delete_appointment_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        delete_appointment_btn.setBounds(540, 25, 192, 51);
        panel.add(delete_appointment_btn);
        delete_appointment_btn.setBackground(SystemColor.info);

//        textFiled = new JTextArea();
//        textFiled.setWrapStyleWord(true);
//        textFiled.setBounds(141, 238, 561, 83);
//
//        panel.add(textFiled);
        scroll = new JScrollPane();
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        homepage_btn = new JButton("BACK");
        homepage_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        homepage_btn.setBounds(29, 94, 142, 23);
        panel.add(homepage_btn);
        homepage_btn.setBackground(SystemColor.info);


        ActionListener a1 = new actionListener();
        add_appointment_btn.addActionListener(a1);
        view_appointment_btn.addActionListener(a1);
        delete_appointment_btn.addActionListener(a1);
        homepage_btn.addActionListener(a1);


    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_appointment_btn)) {
                add_appointment_panel a1 = new add_appointment_panel();
                a1.setVisible(true);

            } else if (a.getSource().equals(view_appointment_btn)) {
                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select * " +
                            " from APPOINTMENTS");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][]{
                            },
                            new String[]{
                                    "ID ", "PET TYPE", "DATE", "DOCTOR ID","Doctor Name"
                            }
                    ) {
                        Class[] columnTypes = new Class[]{
                                String.class, String.class, String.class, String.class,String.class
                        };

                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }

                        boolean[] columnEditables = new boolean[]{
                                false, false, false, false,false
                        };

                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel = (DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[] = {rs.getString(1), rs.getString(2), rs.getString(3),
                                rs.getString(4), pet_doctors.docname(rs.getString(4))};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }




            } else if (a.getSource().equals(delete_appointment_btn)) {
                String apt_id = JOptionPane.showInputDialog("enter appointmentID you want to delete");
                if (appointments.search_appts(apt_id)) {
                    appointments.delete_appointments(apt_id);
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                } else {
                    JOptionPane.showMessageDialog(null, "no such appointment id found");

                }
            } else if (a.getSource().equals(homepage_btn)) {
                services_management s1 = new services_management();
                s1.setVisible(true);
                dispose();
            }

        }
    }
}
