package windows;

import backend.receipts;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class receipt_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_receipt;
    private JButton view_receipt_btn;
    private JButton delete_receipt_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton homepage_btn;


    public receipt_management() {
        initialize();


    }
    private void initialize(){
        ActionListener a1=new actionListener();


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_receipt = new JButton("ADD RECEIPT");
        add_receipt.setBackground(SystemColor.info);
        add_receipt.setBounds(29, 25, 142, 51);
        panel.add(add_receipt);


        view_receipt_btn = new JButton("VIEW RECEIPT");
        view_receipt_btn.setBackground(SystemColor.info);

        view_receipt_btn.setBounds(327, 25, 142, 51);
        panel.add(view_receipt_btn);

        delete_receipt_btn = new JButton("DELETE RECEIPT");
        delete_receipt_btn.setBounds(590, 25, 142, 51);
        panel.add(delete_receipt_btn);
        delete_receipt_btn.setBackground(SystemColor.info);

//        textFiled = new JTextArea();
//        textFiled.setWrapStyleWord(true);
//        textFiled.setBounds(141, 238, 561, 83);
//        textFiled.setEditable(false);

//        panel.add(textFiled);
        scroll = new JScrollPane();
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        homepage_btn = new JButton("Sales management");
        homepage_btn.setBounds(39, 94, 160, 23);
        homepage_btn.setBackground(SystemColor.info);
        panel.add(homepage_btn);

        add_receipt.addActionListener(a1);
        view_receipt_btn.addActionListener(a1);
        delete_receipt_btn.addActionListener(a1);
        homepage_btn.addActionListener(a1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_receipt))
            {
                add_receipt a1=new add_receipt();
                a1.setVisible(true);


            }
            else if (a.getSource().equals(view_receipt_btn))
            {
                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select * " +
                            "from receipts");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][] {
                            },
                            new String[] {
                                    "ReceiptID ", "BillingID","PaidAmount","OrderID"
                            }
                    ) {
                        Class[] columnTypes = new Class[] {
                                String.class, String.class,String.class,String.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                        boolean[] columnEditables = new boolean[] {
                                false, false,false,false
                        };
                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[]={rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }
//                String s="receiptID\t\t\t\tBilingDate\t\t\t\tPaidAmount\t\t\t\tOrderID\n"+"-------------------" +
//                        "-------------------------------------------------------------------" +
//                        "----------------------------------------------------------------" +
//                        "----------------------------------------------------------------" +
//                        "--\n\n";
//                scroll.setVisible(true);
//                textFiled.setText(s+ receipts.view_receipts());
//                textFiled.setEditable(false);
//                scroll.isEnabled();
//                textFiled.setFont(new Font("Tahoma", Font.BOLD, 13));

            }
            else if (a.getSource().equals(delete_receipt_btn))
            {
                String re_id = JOptionPane.showInputDialog("enter receipt id you want ot delete");
                if (receipts.search_receipt(re_id))
                {
                    receipts.delete_receipt(re_id);
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                }
                else
                    JOptionPane.showMessageDialog(null,"no such receipt found");

            }
            else if (a.getSource().equals(homepage_btn))
            {
                sales_management s1=new sales_management();
                s1.setVisible(true);
                dispose();
            }

        }
    }
}