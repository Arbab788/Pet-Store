package windows;


import backend.customers;
import backend.orders;
import backend.receipts;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_receipt extends JDialog {

    private JPanel contentPane;
    private JLabel receipt_id_lbl;
    private JLabel billing_date_lbl;
    private JPanel panel;
    private JLabel paid_amount_lbl;
    private JTextField receit_id_textField;
    private JTextField billing_date_textField_1;
    private JTextField paid_amount_textField_2;
    private JTextField order_id_textField;
    private JLabel error_lbl;
    private JButton create_receipt_btn;
    private JLabel order_id_lbl_1;

    public add_receipt() {
        initialize();
    }
    private void initialize(){

        setBounds(100, 100, 500, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 484, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        receipt_id_lbl = new JLabel("Receipt ID");
        receipt_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        receipt_id_lbl.setBounds(24, 110, 117, 33);
        panel.add(receipt_id_lbl);

        billing_date_lbl = new JLabel("Billing date");
        billing_date_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        billing_date_lbl.setBounds(24, 180, 117, 33);
        panel.add(billing_date_lbl);

        paid_amount_lbl = new JLabel("Paid Amount");
        paid_amount_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        paid_amount_lbl.setBounds(24, 251, 117, 33);
        panel.add(paid_amount_lbl);

        receit_id_textField = new JTextField();
        receit_id_textField.setBounds(151, 110, 221, 33);
        panel.add(receit_id_textField);
        receit_id_textField.setColumns(10);

        billing_date_textField_1 = new JTextField();
        billing_date_textField_1.setColumns(10);
        billing_date_textField_1.setBounds(151, 180, 221, 33);
        panel.add(billing_date_textField_1);

        paid_amount_textField_2 = new JTextField();
        paid_amount_textField_2.setColumns(10);
        paid_amount_textField_2.setBounds(151, 251, 221, 33);
        panel.add(paid_amount_textField_2);

        order_id_textField = new JTextField();
        order_id_textField.setColumns(10);
        order_id_textField.setBounds(151, 319, 221, 33);
        panel.add(order_id_textField);

        order_id_lbl_1 = new JLabel("Order ID");
        order_id_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        order_id_lbl_1.setBounds(24, 319, 117, 33);
        panel.add(order_id_lbl_1);

        error_lbl = new JLabel("error to display");
        error_lbl.setForeground(Color.RED);
        error_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        error_lbl.setHorizontalAlignment(SwingConstants.CENTER);
        error_lbl.setBounds(61, 371, 364, 33);
        panel.add(error_lbl);

        create_receipt_btn = new JButton("Create Receipt");
        create_receipt_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        create_receipt_btn.setBackground(Color.WHITE);
        create_receipt_btn.setForeground(Color.DARK_GRAY);
        create_receipt_btn.setBounds(172, 415, 162, 35);
        panel.add(create_receipt_btn);
        ActionListener a1=new actionListener();
        create_receipt_btn.addActionListener(a1);
        receit_id_textField.setText(receipts.generate_receipt_ID());
        receit_id_textField.setEditable(false);
        billing_date_textField_1.setText(String.valueOf(java.time.LocalDate.now()));
        billing_date_textField_1.setEditable(false);


    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(create_receipt_btn))
            {
                boolean valid=true;
                if (!customers.isdigitOnly(paid_amount_textField_2.getText()))
                {
                    valid=false;
                    error_lbl.setText("invalid price");

                }
                if (!customers.isdigitOnly(order_id_textField.getText()))
                {
                    valid=false;
                    error_lbl.setText("invalid orderID");
                }
                if (!valid);
                else
                {
                    if (!receipts.neworder(order_id_textField.getText()))
                    {
                        error_lbl.setVisible(true);
                        error_lbl.setText("receipt already generated");
                    }

                    else if (orders.searchorder(order_id_textField.getText()))
                    {
                        receipts.add_receipt(receit_id_textField.getText(),billing_date_textField_1.getText(),
                                paid_amount_textField_2.getText(),order_id_textField.getText());
                        JOptionPane.showMessageDialog(null,"added");
                        setVisible(false);
                        new add_receipt().setVisible(true);
                    }
                    else{
                        error_lbl.setText("no such order id found");
                    }

                }

            }

        }
    }

}
