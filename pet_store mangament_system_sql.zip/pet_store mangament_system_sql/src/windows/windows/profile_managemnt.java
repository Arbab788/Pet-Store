package windows;

import backend.admin;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class profile_managemnt extends JFrame {

    private JPanel contentPane;
    private JLabel panel;
    private JButton addUser_btn;
    private JButton viewUser_btn;
    private JButton updateUser_btn;
    private JButton deleteUser_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton homepage_btn;
    private JButton update_user_btn_1;
    private JScrollPane scrollPane;
    private JTable table;


    public profile_managemnt() {
        initialize();

    }

    private void initialize() {
        ActionListener a1 = new actionListener();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JLabel();
//        panel.setBackground(Color.GREEN);
        Icon icon = new ImageIcon(homePage.class.getResource("/resources/users.jpg"));
        panel.setIcon(icon);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        addUser_btn = new JButton("ADD USER");
        addUser_btn.setBackground(SystemColor.info);
        addUser_btn.setBounds(29, 25, 142, 51);
        addUser_btn.addActionListener(a1);
        panel.add(addUser_btn);

        viewUser_btn = new JButton("VIEW USER");
        viewUser_btn.setBackground(SystemColor.info);
        viewUser_btn.setBounds(193, 25, 142, 51);
        panel.add(viewUser_btn);
        viewUser_btn.addActionListener(a1);

        deleteUser_btn = new JButton("DELETE USER");
        deleteUser_btn.setBounds(590, 25, 142, 51);
        panel.add(deleteUser_btn);
        deleteUser_btn.setBackground(SystemColor.info);
        deleteUser_btn.addActionListener(a1);

        update_user_btn_1 = new JButton("UPDATE USER");
        update_user_btn_1.setBackground(SystemColor.info);
        update_user_btn_1.setBounds(387, 25, 142, 51);
        panel.add(update_user_btn_1);
        update_user_btn_1.addActionListener(a1);

//        textFiled = new JTextArea();
//        textFiled.setWrapStyleWord(true);
//        textFiled.setBounds(29, 128, 703, 322);
//
//        panel.add(textFiled);
//        scroll = new JScrollPane(textFiled);
//        scroll.setBounds(29, 128, 703, 322);
//        scroll.setVisible(false);
//        panel.add(scroll);

        homepage_btn = new JButton("homePage");
        homepage_btn.setBounds(39, 94, 200, 23);
        panel.add(homepage_btn);
        homepage_btn.setBackground(SystemColor.info);
        homepage_btn.addActionListener(a1);



//        ==============================================================

        scrollPane = new JScrollPane();
        scrollPane.setBounds(87, 147, 641, 255);
        panel.add(scrollPane);


    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(homepage_btn)) {
                dispose();
                homePage h1 = new homePage();
                h1.setVisible(true);
            }
            else if (a.getSource().equals(addUser_btn)) {
                AdduserPanel a1 = new AdduserPanel();
                a1.setVisible(true);
            }
            else if (a.getSource().equals(viewUser_btn)) {

                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select user_name, " +
                            "password from admin");
                    ResultSet rs = queryStatement.executeQuery();
                    table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][] {
                            },
                            new String[] {
                                    "username ", "password"
                            }
                    ) {
                        Class[] columnTypes = new Class[] {
                                String.class, String.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                    });
                    scrollPane.setViewportView(table);
                    DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[]={rs.getString(1),rs.getString(2)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }
            }
            else if (a.getSource().equals(deleteUser_btn)) {
                String username = JOptionPane.showInputDialog("enter username of to delete account");
                if (admin.searchUser(username)) {
                    admin.deleteUsers(username);
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                    if (username.equals(signin.currentadm().getUser_name())) {
                        signin s1 = new signin();
                        s1.setVisible(true);
                        dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "no such user found");
                }
            }
            else if (a.getSource().equals(update_user_btn_1)) {
                String username = JOptionPane.showInputDialog("enter username of to update account");
                if (admin.searchUser(username)) {
                    updateuserPanel q = new updateuserPanel(username);
                    q.setVisible(true);

                }
                else {
                    JOptionPane.showMessageDialog(null, "no such user found");
                }
            }

        }

    }
}



