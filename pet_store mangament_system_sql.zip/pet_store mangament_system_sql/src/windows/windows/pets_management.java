package windows;

import backend.pets;
import backend.products;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class pets_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_pets_btn;
    private JButton view_pets_btn;
    private JButton update_pets_btn;
    private JButton products_manag_btn;
    private JButton delete_pts_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;


    public pets_management() {
        initializie();

    }
    private void initializie(){
        ActionListener a1=new actionListener();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_pets_btn = new JButton("ADD PETS ");
        add_pets_btn.setForeground(new Color(0, 0, 0));
        add_pets_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_pets_btn.setBackground(SystemColor.info);
        add_pets_btn.setBounds(29, 25, 151, 42);
        panel.add(add_pets_btn);
        add_pets_btn.addActionListener(a1);

        view_pets_btn = new JButton("VIEW PETS");
        view_pets_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        view_pets_btn.setBackground(SystemColor.info);
        view_pets_btn.addActionListener(a1);

        view_pets_btn.setBounds(206, 25, 151, 42);
        panel.add(view_pets_btn);

        update_pets_btn = new JButton("UPDATE PET");
        update_pets_btn.setBackground(SystemColor.info);
        update_pets_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_pets_btn.setBounds(389, 25, 151, 42);
        panel.add(update_pets_btn);
        update_pets_btn.addActionListener(a1);

        products_manag_btn = new JButton("Products management");
        products_manag_btn.setBackground(SystemColor.info);
        products_manag_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        products_manag_btn.setBounds(29, 89, 207, 33);
        panel.add(products_manag_btn);
        products_manag_btn.addActionListener(a1);

        delete_pts_btn = new JButton("DELETE PET");
        delete_pts_btn.setForeground(Color.BLACK);
        delete_pts_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        delete_pts_btn.setBackground(SystemColor.info);
        delete_pts_btn.setBounds(568, 25, 151, 42);
        panel.add(delete_pts_btn);
        delete_pts_btn.addActionListener(a1);

        textFiled = new JTextArea();
        textFiled.setWrapStyleWord(true);
        textFiled.setBounds(141, 238, 561, 83);

        panel.add(textFiled);
        scroll = new JScrollPane(textFiled);
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_pets_btn))
            {
                add_pets_panel a1=new add_pets_panel();
                a1.setVisible(true);

            }
            else if (a.getSource().equals(view_pets_btn))
            {
                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select *" +
                            " from pets");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][] {
                            },
                            new String[] {
                                    "ID ", "PRICE","COLOR","BREED"
                            }
                    ) {
                        Class[] columnTypes = new Class[] {
                                String.class, String.class,String.class,String.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                        boolean[] columnEditables = new boolean[] {
                                false, false,false,false
                        };
                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[]={rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }


//                String s="ProdID\t\t\tPetID\t\t\tPrice\t\t\tColor\t\t\tBreed\n"+"-------------------" +
//                        "--------------------------------------" +
//                        "----------------------------------------------------------------" +
//                        "--------------------------------------------------------------------------------------" +
//                        "--\n\n";
//                scroll.setVisible(true);
//                textFiled.setText(s+ pets.viewpets());
//                textFiled.setEditable(false);
//                scroll.isEnabled();
//                textFiled.setFont(new Font("Tahoma", Font.BOLD, 13));

            }
            else if (a.getSource().equals(update_pets_btn))
            {
                String pet_id=JOptionPane.showInputDialog("enter pet ID you want to update");
                if(pets.search_pet(pet_id)){
                    update_pets_panel p=new update_pets_panel(pet_id);
                    p.setVisible(true);


                }
                else
                {
                    JOptionPane.showMessageDialog(null,"no such pet id found");

                }

            }
            else if (a.getSource().equals(delete_pts_btn))
            {
                String pet_id=JOptionPane.showInputDialog("enter pet ID you want to delete");
                if (pets.search_pet(pet_id)){

                    products.delete_products(pet_id);

                }
                else
                {
                    JOptionPane.showMessageDialog(null,"no such pet id found");
                }

            }
            else if(a.getSource().equals(products_manag_btn))
            {
                products_management p=new products_management();
                p.setVisible(true);
                dispose();
            }
        }
    }

}

