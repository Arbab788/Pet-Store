package windows;

import backend.customers;
import backend.orders;
import backend.products;
import backend.shipment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class addorder extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JLabel order_id_lbl;
    private JLabel order_date_lbl;
    private JLabel product_id_lbl;
    private JLabel customer_id_lbl;
    private JTextField orderid_textField;
    private JTextField customerID_textField_1;
    private JTextField product_id_textField_2;
    private JTextField order_date_textField_3;
    private JButton add_order_btn;
    private JLabel sipment_id_lbl;
    private JLabel shipment_date_lbl_1;
    private JTextField shipment_id_textField;
    private JTextField order_date_textField_1;
    private JLabel error_lbl;
    private JLabel order_id_error_lbl;
    private JLabel customer_id_error_lbl_1;
    private JLabel prod_id_error_lbl_2;
    private JLabel shipment_id_error_lbl_4;

    public addorder() {
        initialize();

    }

    private void initialize() {
        ActionListener a1 = new actionListener();
        setBounds(119, 11, 688, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 672, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        order_id_lbl = new JLabel("order id");
        order_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        order_id_lbl.setBounds(32, 94, 128, 26);
        panel.add(order_id_lbl);

        customer_id_lbl = new JLabel("customer id");
        customer_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        customer_id_lbl.setBounds(32, 145, 128, 26);
        panel.add(customer_id_lbl);

        product_id_lbl = new JLabel("product id");
        product_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        product_id_lbl.setBounds(32, 201, 128, 26);
        panel.add(product_id_lbl);

        order_date_lbl = new JLabel("order date");
        order_date_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        order_date_lbl.setBounds(32, 258, 128, 26);
        panel.add(order_date_lbl);

        orderid_textField = new JTextField();
        orderid_textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
        orderid_textField.setBounds(186, 94, 173, 26);
        panel.add(orderid_textField);
        orderid_textField.setColumns(10);

        customerID_textField_1 = new JTextField();
        customerID_textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
        customerID_textField_1.setColumns(10);
        customerID_textField_1.setBounds(186, 149, 173, 26);
        panel.add(customerID_textField_1);

        product_id_textField_2 = new JTextField();
        product_id_textField_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
        product_id_textField_2.setColumns(10);
        product_id_textField_2.setBounds(186, 201, 173, 26);
        panel.add(product_id_textField_2);

        order_date_textField_3 = new JTextField();
        order_date_textField_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
        order_date_textField_3.setColumns(10);
        order_date_textField_3.setBounds(186, 258, 173, 26);
        panel.add(order_date_textField_3);

        error_lbl = new JLabel("");
        error_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        error_lbl.setForeground(Color.RED);
        error_lbl.setHorizontalAlignment(SwingConstants.CENTER);
        error_lbl.setBounds(81, 396, 375, 26);
        panel.add(error_lbl);

        add_order_btn = new JButton("add order");
        add_order_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_order_btn.setBackground(SystemColor.inactiveCaptionBorder);
        add_order_btn.setForeground(SystemColor.textHighlight);
        add_order_btn.setBounds(198, 421, 147, 23);
        panel.add(add_order_btn);

        sipment_id_lbl = new JLabel("shipment id");
        sipment_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        sipment_id_lbl.setBounds(32, 307, 128, 26);
        panel.add(sipment_id_lbl);

        shipment_date_lbl_1 = new JLabel("shipment date");
        shipment_date_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        shipment_date_lbl_1.setBounds(32, 361, 128, 26);
        panel.add(shipment_date_lbl_1);

        shipment_id_textField = new JTextField();
        shipment_id_textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
        shipment_id_textField.setColumns(10);
        shipment_id_textField.setBounds(186, 311, 173, 26);
        panel.add(shipment_id_textField);

        order_date_textField_1 = new JTextField();
        order_date_textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
        order_date_textField_1.setColumns(10);
        order_date_textField_1.setBounds(186, 361, 173, 26);
        panel.add(order_date_textField_1);
        add_order_btn.addActionListener(a1);

        order_id_error_lbl = new JLabel("");
        order_id_error_lbl.setHorizontalAlignment(SwingConstants.LEFT);
        order_id_error_lbl.setForeground(Color.RED);
        order_id_error_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        order_id_error_lbl.setBounds(378, 94, 284, 26);
        panel.add(order_id_error_lbl);

        customer_id_error_lbl_1 = new JLabel("");
        customer_id_error_lbl_1.setHorizontalAlignment(SwingConstants.LEFT);
        customer_id_error_lbl_1.setForeground(Color.RED);
        customer_id_error_lbl_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        customer_id_error_lbl_1.setBounds(378, 152, 284, 26);
        panel.add(customer_id_error_lbl_1);

        prod_id_error_lbl_2 = new JLabel("error to be dispaly here");
        prod_id_error_lbl_2.setHorizontalAlignment(SwingConstants.LEFT);
        prod_id_error_lbl_2.setForeground(Color.RED);
        prod_id_error_lbl_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        prod_id_error_lbl_2.setBounds(378, 208, 284, 26);
        panel.add(prod_id_error_lbl_2);

        shipment_id_error_lbl_4 = new JLabel("");
        shipment_id_error_lbl_4.setHorizontalAlignment(SwingConstants.LEFT);
        shipment_id_error_lbl_4.setForeground(Color.RED);
        shipment_id_error_lbl_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        shipment_id_error_lbl_4.setBounds(378, 314, 284, 26);
        panel.add(shipment_id_error_lbl_4);
        orderid_textField.setText(orders.generateOrderID());
        orderid_textField.setEditable(false);
        shipment_id_textField.setText(shipment.generateshipmentID());
        shipment_id_textField.setEditable(false);
        order_date_textField_1.setText(String.valueOf(java.time.LocalDate.now()));
        order_date_textField_1.setEditable(false);
        order_date_textField_3.setText(String.valueOf(java.time.LocalDate.now()));
        order_date_textField_3.setEditable(false);

        prod_id_error_lbl_2.setVisible(false);
        customer_id_error_lbl_1.setVisible(false);
        shipment_id_error_lbl_4.setVisible(false);


    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_order_btn)) {

                boolean valid = true;
                if (!customers.isdigitOnly(customerID_textField_1.getText())) {
                    valid = false;
                    customer_id_error_lbl_1.setText("digits only");
                    customer_id_error_lbl_1.setVisible(true);
                }
                if (!customers.isdigitOnly(product_id_textField_2.getText())) {
                    valid = false;
                    prod_id_error_lbl_2.setText("digits only");
                    prod_id_error_lbl_2.setVisible(true);

                }
                if (!valid) ;
                else {
                    boolean found = true;
                    if (!customers.searchCustomerID(customerID_textField_1.getText())) {
                        found = false;
                        customer_id_error_lbl_1.setText("no such id found");
                        customer_id_error_lbl_1.setVisible(true);
                    }
                    if (!products.searchproduct(product_id_textField_2.getText())) {
                        found = false;
                        prod_id_error_lbl_2.setText("no such id found");
                        prod_id_error_lbl_2.setVisible(true);
                    }
                    if (!found) ;
                    else {
                        if (orders.productAvailable(product_id_textField_2.getText())) {
                            orders.add_orders(orderid_textField.getText(), order_date_textField_1.getText(), customerID_textField_1.getText(),
                                    product_id_textField_2.getText());
                            shipment.add_shipment(shipment_id_textField.getText(), order_date_textField_1.getText(),
                                    orderid_textField.getText());
                            setVisible(false);
                            new addorder().setVisible(true);
                        } else {
                            prod_id_error_lbl_2.setText("product already sold");
                            prod_id_error_lbl_2.setVisible(true);
                        }

                    }
                }

            }
        }
    }

}
