package windows;

import backend.customers;
import backend.pets;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class update_pets_panel extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_btn;
    private JLabel pet_price_lbl;
    private JTextField price_textField_2;
    private JLabel price_ERRor_lbl;
    private JLabel pet_color_lbl;
    private JLabel petbreed_lbl;
    private JLabel pet_added_msg_lbl;
    private JComboBox comboBox;
    private JComboBox colors_comboBox_1;
    private String idl;

    public update_pets_panel(String pet_id) {
        initialize();
        idl=pet_id;
    }
    private void initialize(){
        ActionListener a1=new actionListener();

        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        add_btn = new JButton("UPDATE");
        add_btn.setBackground(Color.GRAY);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setForeground(Color.WHITE);
        add_btn.setBounds(166, 272, 133, 35);
        panel.add(add_btn);

        pet_price_lbl = new JLabel("PRICE");
        pet_price_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        pet_price_lbl.setBounds(10, 117, 119, 27);
        panel.add(pet_price_lbl);

        price_textField_2 = new JTextField();
        price_textField_2.setColumns(10);
        price_textField_2.setBounds(139, 118, 184, 27);
        panel.add(price_textField_2);

        price_ERRor_lbl = new JLabel("DIGITS ONLY");
        price_ERRor_lbl.setForeground(Color.RED);
        price_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        price_ERRor_lbl.setBounds(345, 117, 199, 27);
        panel.add(price_ERRor_lbl);

        pet_color_lbl = new JLabel("COLOR");
        pet_color_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        pet_color_lbl.setBounds(10, 155, 119, 27);
        panel.add(pet_color_lbl);

        petbreed_lbl = new JLabel("BREED");
        petbreed_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        petbreed_lbl.setBounds(10, 193, 119, 27);
        panel.add(petbreed_lbl);

        pet_added_msg_lbl = new JLabel("Pet Updated");
        pet_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
        pet_added_msg_lbl.setForeground(Color.RED);
        pet_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        pet_added_msg_lbl.setBounds(183, 234, 199, 27);
        panel.add(pet_added_msg_lbl);
        pet_added_msg_lbl.setVisible(false);

        String s1[]= {"german","pitbull","pointer","husky","rot wiler"};
        comboBox = new JComboBox(s1);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
        comboBox.setBounds(139, 196, 184, 27);
        panel.add(comboBox);
        add_btn.addActionListener(a1);

        String colors[]= {"brown","grey","white","off whiite"};
        colors_comboBox_1 = new JComboBox(colors);
        colors_comboBox_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        colors_comboBox_1.setBounds(139, 158, 184, 27);
        panel.add(colors_comboBox_1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn))
            {
                if (!customers.isdigitOnly(price_textField_2.getText()))
                {
                    System.out.println("price error");
                }
                else{
                    pets.updatePet(price_textField_2.getText(),String.valueOf(colors_comboBox_1.getSelectedItem()),
                            String.valueOf(comboBox.getSelectedItem()),idl);
                    JOptionPane.showMessageDialog(null,"updated");
                    setVisible(false);
                }
                System.out.println("updated");
            }

        }
    }

}
