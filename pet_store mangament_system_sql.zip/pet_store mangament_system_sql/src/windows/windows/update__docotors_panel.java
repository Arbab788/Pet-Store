package windows;

import backend.customers;
import backend.pet_doctors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class update__docotors_panel extends JDialog {

    private JPanel contentPane;
    private JLabel first_name_lbl;
    private JPanel panel;
    private JLabel paid_amount_lbl;
    private JTextField first_name_textField_1;
    private JTextField last_name_textField_2;
    private JTextField fees_textField;
    private JLabel error_lbl;
    private JButton add_doc_btn;
    private String doctor_id;
    private JLabel first_name_err_lbl_1;
    private JLabel last_name_error_lbl_1_1;
    private JLabel fees_error_lbl_1_2;

    public update__docotors_panel(String docId) {
        doctor_id = docId;
        initialize();
    }

    private void initialize() {
        setBounds(100, 100, 662, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 646, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        first_name_lbl = new JLabel("First Name");
        first_name_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        first_name_lbl.setBounds(24, 180, 117, 33);
        panel.add(first_name_lbl);

        paid_amount_lbl = new JLabel("Last Name");
        paid_amount_lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
        paid_amount_lbl.setBounds(24, 251, 117, 33);
        panel.add(paid_amount_lbl);

        first_name_textField_1 = new JTextField();
        first_name_textField_1.setColumns(10);
        first_name_textField_1.setBounds(151, 180, 221, 33);
        panel.add(first_name_textField_1);

        last_name_textField_2 = new JTextField();
        last_name_textField_2.setColumns(10);
        last_name_textField_2.setBounds(151, 251, 221, 33);
        panel.add(last_name_textField_2);

        fees_textField = new JTextField();
        fees_textField.setColumns(10);
        fees_textField.setBounds(151, 319, 221, 33);
        panel.add(fees_textField);

        JLabel fees_lbl_1 = new JLabel("Fees");
        fees_lbl_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        fees_lbl_1.setBounds(24, 319, 117, 33);
        panel.add(fees_lbl_1);

        error_lbl = new JLabel("doctors added");
        error_lbl.setForeground(Color.RED);
        error_lbl.setFont(new Font("Tahoma", Font.ITALIC, 13));
        error_lbl.setHorizontalAlignment(SwingConstants.CENTER);
        error_lbl.setBounds(61, 371, 364, 33);
        panel.add(error_lbl);

        add_doc_btn = new JButton("Update Doctor");
        add_doc_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_doc_btn.setBackground(Color.WHITE);
        add_doc_btn.setForeground(Color.DARK_GRAY);
        add_doc_btn.setBounds(172, 415, 162, 35);
        panel.add(add_doc_btn);

        first_name_err_lbl_1 = new JLabel("alphabets only");
        first_name_err_lbl_1.setHorizontalAlignment(SwingConstants.CENTER);
        first_name_err_lbl_1.setForeground(Color.RED);
        first_name_err_lbl_1.setFont(new Font("Tahoma", Font.ITALIC, 13));
        first_name_err_lbl_1.setBounds(399, 180, 237, 33);
        panel.add(first_name_err_lbl_1);

        last_name_error_lbl_1_1 = new JLabel("alphabets only");
        last_name_error_lbl_1_1.setHorizontalAlignment(SwingConstants.CENTER);
        last_name_error_lbl_1_1.setForeground(Color.RED);
        last_name_error_lbl_1_1.setFont(new Font("Tahoma", Font.ITALIC, 13));
        last_name_error_lbl_1_1.setBounds(399, 251, 237, 33);
        panel.add(last_name_error_lbl_1_1);

        fees_error_lbl_1_2 = new JLabel("digits only");
        fees_error_lbl_1_2.setHorizontalAlignment(SwingConstants.CENTER);
        fees_error_lbl_1_2.setForeground(Color.RED);
        fees_error_lbl_1_2.setFont(new Font("Tahoma", Font.ITALIC, 13));
        fees_error_lbl_1_2.setBounds(399, 319, 237, 33);
        panel.add(fees_error_lbl_1_2);
        ActionListener a1 = new actionListener();
        add_doc_btn.addActionListener(a1);
        first_name_err_lbl_1.setVisible(false);
        last_name_error_lbl_1_1.setVisible(false);
        fees_error_lbl_1_2.setVisible(false);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_doc_btn)) {
                boolean valid = true;
                if (!customers.isStringOnlyAlphabet(first_name_textField_1.getText())) {
                    valid = false;
                    first_name_err_lbl_1.setVisible(true);

                }
                if (!customers.isStringOnlyAlphabet(last_name_textField_2.getText())) {
                    valid = false;
                    last_name_error_lbl_1_1.setVisible(true);
                }
                if (!customers.isdigitOnly(fees_textField.getText())) {
                    valid = false;
                    fees_error_lbl_1_2.setVisible(true);
                }
                if (!valid) ;
                else {
                    pet_doctors.update_doctor(first_name_textField_1.getText(), last_name_textField_2.getText(),
                            fees_textField.getText(), doctor_id);
                    JOptionPane.showMessageDialog(null,"updated");
                    setVisible(false);
                }
            }

        }
    }

}