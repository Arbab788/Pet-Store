package windows;


import backend.customers;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class update_customer extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton update_btn;
    private JLabel customer_firstname_lbl;
    private JTextField firstnametextField_1;
    private JLabel FirstName_ERRor_lbl;
    private JLabel customer_Lastname_lbl;
    private JTextField lastnametextField_2;
    private JLabel LASTNAME_ERRor_lbl;
    private JLabel updated_msgLbl;
    private String id;
    public update_customer(String cusid) {
        id=cusid;
        initialize();
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    private void initialize(){
        ActionListener a1=new actionListener();
        setBounds(100, 100, 500, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 484, 261);
        contentPane.add(panel);
        panel.setLayout(null);

        update_btn = new JButton("Update");
        update_btn.setBackground(Color.GRAY);
        update_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_btn.setForeground(Color.WHITE);
        update_btn.setBounds(157, 200, 133, 35);
        panel.add(update_btn);
        update_btn.addActionListener(a1);

        customer_firstname_lbl = new JLabel("First Name");
        customer_firstname_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        customer_firstname_lbl.setBounds(10, 79, 119, 27);
        panel.add(customer_firstname_lbl);

        firstnametextField_1 = new JTextField();
        firstnametextField_1.setColumns(10);
        firstnametextField_1.setBounds(139, 80, 184, 27);
        panel.add(firstnametextField_1);

        FirstName_ERRor_lbl = new JLabel("ALPHABETS ONLY");
        FirstName_ERRor_lbl.setForeground(Color.RED);
        FirstName_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        FirstName_ERRor_lbl.setBounds(333, 79, 199, 27);
        panel.add(FirstName_ERRor_lbl);

        customer_Lastname_lbl = new JLabel("Last Name");
        customer_Lastname_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        customer_Lastname_lbl.setBounds(10, 117, 119, 27);
        panel.add(customer_Lastname_lbl);

        lastnametextField_2 = new JTextField();
        lastnametextField_2.setColumns(10);
        lastnametextField_2.setBounds(139, 118, 184, 27);
        panel.add(lastnametextField_2);

        LASTNAME_ERRor_lbl = new JLabel("ALPHABETS ONLY");
        LASTNAME_ERRor_lbl.setForeground(Color.RED);
        LASTNAME_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        LASTNAME_ERRor_lbl.setBounds(333, 117, 199, 27);
        panel.add(LASTNAME_ERRor_lbl);

        updated_msgLbl = new JLabel("Updated!!");
        updated_msgLbl.setForeground(Color.RED);
        updated_msgLbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        updated_msgLbl.setBounds(188, 162, 124, 27);
        panel.add(updated_msgLbl);
        updated_msgLbl.setVisible(false);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(update_btn))
            {
                boolean update=true;
                if (!customers.isStringOnlyAlphabet(firstnametextField_1.getText()))
                {
                    update=false;
                    FirstName_ERRor_lbl.setVisible(true);
                }
                if (!customers.isStringOnlyAlphabet(lastnametextField_2.getText()))
                {
                    update=false;
                    LASTNAME_ERRor_lbl.setVisible(true);

                }
                if (!update);
                else{
                    customers.updateCustomer(id,firstnametextField_1.getText(),lastnametextField_2.getText());
                    JOptionPane.showMessageDialog(null,"updated");
                    setVisible(false);
                }

            }


        }
    }

}
