package windows;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class products_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton pets_mang_btn;
    private JButton accessories_mang_btn;
    private JButton petfood_mang_btn;
    private JButton homepage_btn;
    private JButton vaccination_mang_btn_1;

    public products_management() {
        initialize();
    }
    private void initialize(){
        ActionListener a1=new actionListener();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        pets_mang_btn = new JButton("PETS ");
        pets_mang_btn.setForeground(new Color(0, 0, 0));
        pets_mang_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        pets_mang_btn.setBackground(SystemColor.info);
        pets_mang_btn.setBounds(29, 25, 151, 42);
        panel.add(pets_mang_btn);
        pets_mang_btn.addActionListener(a1);

        accessories_mang_btn = new JButton("ACCESSORIES");
        accessories_mang_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        accessories_mang_btn.setBackground(SystemColor.info);
        accessories_mang_btn.addActionListener(a1);

        accessories_mang_btn.setBounds(206, 25, 151, 42);
        panel.add(accessories_mang_btn);

        petfood_mang_btn = new JButton("PET FOOD");
        petfood_mang_btn.setBackground(SystemColor.info);
        petfood_mang_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        petfood_mang_btn.setBounds(389, 25, 151, 42);
        panel.add(petfood_mang_btn);
        petfood_mang_btn.addActionListener(a1);

        homepage_btn = new JButton("homePage");
        homepage_btn.setBackground(SystemColor.info);
        homepage_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        homepage_btn.setBounds(29, 89, 132, 33);
        panel.add(homepage_btn);
        homepage_btn.addActionListener(a1);

        vaccination_mang_btn_1 = new JButton("VACCINATIONS");
        vaccination_mang_btn_1.setForeground(Color.BLACK);
        vaccination_mang_btn_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        vaccination_mang_btn_1.setBackground(SystemColor.info);
        vaccination_mang_btn_1.setBounds(568, 25, 151, 42);
        vaccination_mang_btn_1.addActionListener(a1);
        panel.add(vaccination_mang_btn_1);
    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(pets_mang_btn))
            {
                pets_management p1=new pets_management();
                p1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(accessories_mang_btn))
            {
                accessories_management aa=new accessories_management();
                aa.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(petfood_mang_btn))
            {
                pet_food_management p1=new pet_food_management();
                p1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(vaccination_mang_btn_1))
            {
                vacination_management v1=new vacination_management();
                v1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(homepage_btn))
            {
                homePage h1=new homePage();
                h1.setVisible(true);
                dispose();
            }
        }
    }

}
