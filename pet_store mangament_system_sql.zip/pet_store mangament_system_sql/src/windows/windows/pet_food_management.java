package windows;

import backend.pet_food;
import backend.products;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class pet_food_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_food_btn;
    private JButton view_food_btn;
    private JButton update_food_btn;
    private JButton products_manag_btn;
    private JButton delete_food_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton search_food_btn_1;

    public pet_food_management() {
        initialize();
    }

    private void initialize() {
        ActionListener a1 = new actionListener();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_food_btn = new JButton("ADD FOOD");
        add_food_btn.setForeground(new Color(0, 0, 0));
        add_food_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_food_btn.setBackground(SystemColor.info);
        add_food_btn.setBounds(29, 25, 167, 42);
        panel.add(add_food_btn);
        add_food_btn.addActionListener(a1);

        view_food_btn = new JButton("VIEW FOOD");
        view_food_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        view_food_btn.setBackground(SystemColor.info);

        view_food_btn.setBounds(206, 25, 184, 42);
        panel.add(view_food_btn);
        view_food_btn.addActionListener(a1);

        update_food_btn = new JButton("UPDATE FOOD");
        update_food_btn.setBackground(SystemColor.info);
        update_food_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_food_btn.setBounds(400, 25, 186, 42);
        panel.add(update_food_btn);
        update_food_btn.addActionListener(a1);

        products_manag_btn = new JButton("Products management");
        products_manag_btn.setBackground(SystemColor.info);
        products_manag_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        products_manag_btn.setBounds(29, 89, 207, 33);
        panel.add(products_manag_btn);
        products_manag_btn.addActionListener(a1);

        delete_food_btn = new JButton("DELETE FOOD");
        delete_food_btn.setForeground(Color.BLACK);
        delete_food_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        delete_food_btn.setBackground(SystemColor.info);
        delete_food_btn.setBounds(596, 25, 178, 42);
        panel.add(delete_food_btn);
        delete_food_btn.addActionListener(a1);

        textFiled = new JTextArea();
        textFiled.setWrapStyleWord(true);
        textFiled.setBounds(141, 238, 561, 83);

        panel.add(textFiled);
        scroll = new JScrollPane(textFiled);
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        search_food_btn_1 = new JButton("SEARCH FOOD");
        search_food_btn_1.setFont(new Font("Tahoma", Font.BOLD, 13));
        search_food_btn_1.setBackground(SystemColor.info);
        search_food_btn_1.setBounds(596, 84, 178, 42);
        panel.add(search_food_btn_1);
        search_food_btn_1.addActionListener(a1);
        scroll.setVisible(false);
        textFiled.setEditable(false);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_food_btn)) {
                add_petFood_panel p = new add_petFood_panel();
                p.setVisible(true);
                System.out.println("add food");
            } else if (a.getSource().equals(view_food_btn)) {
                scroll.setVisible(true);

                Connection connection;

                try {
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select *" +
                            " from pet_food");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][]{
                            },
                            new String[]{
                                    "ID ", "PRICE", "WEIGHT(KG)", "NAME"
                            }
                    ) {
                        Class[] columnTypes = new Class[]{
                                String.class, String.class, String.class, String.class
                        };

                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }

                        boolean[] columnEditables = new boolean[]{
                                false, false, false, false
                        };

                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel = (DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[] = {rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }


//
//                String s="ProdID\t\t\tfoodID\t\t\tPrice\t\t\twight\t\t\tName\n"+"-------------------" +
//                        "--------------------------------------" +
//                        "----------------------------------------------------------------" +
//                        "--------------------------------------------------------------------------------------" +
//                        "--\n\n";
//                scroll.setVisible(true);
//                textFiled.setText(s+ pet_food.viewfood());
//                textFiled.setEditable(false);
//                scroll.isEnabled();
//                textFiled.setFont(new Font("Tahoma", Font.BOLD, 13));

            } else if (a.getSource().equals(update_food_btn)) {
                String food_id = JOptionPane.showInputDialog("enter pet food ID you want to update");
                if (pet_food.search_food(food_id)) {
                    update_petFood_panel p = new update_petFood_panel(food_id);
                    p.setVisible(true);

                } else {

                    JOptionPane.showMessageDialog(null, "no such id found");

                }

            } else if (a.getSource().equals(delete_food_btn)) {
                String food_id = JOptionPane.showInputDialog("enter pet food ID you want to delete");
                if (pet_food.search_food(food_id)) {
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                    products.delete_products(food_id);
                } else {
                    JOptionPane.showMessageDialog(null, "no such  id found");
                }
                System.out.println("delleer");

            } else if (a.getSource().equals(search_food_btn_1)) {
                String food_id = JOptionPane.showInputDialog("enter pet food ID you want to search");
                if (pet_food.search_food(food_id)) {

                    JOptionPane.showMessageDialog(null, "Found");
                    scroll.setVisible(true);

                    Connection connection;

                    try {
                        connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                        PreparedStatement queryStatement = connection.prepareStatement("select *" +
                                " from pet_food where food_id=?");
                        queryStatement.setString(1, food_id);
                        ResultSet rs = queryStatement.executeQuery();
                        JTable table = new JTable();
                        table.setModel(new DefaultTableModel(
                                new Object[][]{
                                },
                                new String[]{
                                        "ID ", "PRICE", "WEIGHT(KG)", "NAME"
                                }
                        ) {
                            Class[] columnTypes = new Class[]{
                                    String.class, String.class, String.class, String.class
                            };

                            public Class getColumnClass(int columnIndex) {
                                return columnTypes[columnIndex];
                            }

                            boolean[] columnEditables = new boolean[]{
                                    false, false, false, false
                            };

                            public boolean isCellEditable(int row, int column) {
                                return columnEditables[column];
                            }
                        });
                        scroll.setViewportView(table);
                        DefaultTableModel tbModel = (DefaultTableModel) table.getModel();

                        while (rs.next()) {
                            String tbData[] = {rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)};
                            tbModel.addRow(tbData);

                        }

                    } catch (Exception e) {
                        System.out.println(e);
                    }


                } else {
                    JOptionPane.showMessageDialog(null, "no such  id found");
                }
                System.out.println("search");
            } else if (a.getSource().equals(products_manag_btn)) {
                products_management p1 = new products_management();
                p1.setVisible(true);
                dispose();
            }
        }
    }

}
