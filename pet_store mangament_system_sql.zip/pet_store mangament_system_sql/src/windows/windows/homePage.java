package windows;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class homePage extends JFrame {

    private JPanel contentPane;
    private JLabel panel;
    private JButton salesMang_btn;
    private JButton staffMang_btn;
    private JButton servicesMang_btn;
    private JButton productsMang_btn;
    private JButton profileMng_btn;
    private mainWindows frame;
    private JButton signOut_btn;

    /**
     * Launch the application.
     */


    /**
     * Create the frame.
     */
    public homePage() {
        initialize();

    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JLabel();
        Icon icon = new ImageIcon(homePage.class.getResource("/resources/pets7.jpg"));
        panel.setIcon(icon);
        panel.setFont(new Font("Tahoma", Font.BOLD, 15));
//        panel.setBackground(new Color(84, 171, 187));
        panel.setBounds(0, 0, 784, 461);
//        panel.setBackground(SystemColor.RED);
        contentPane.add(panel);
        panel.setLayout(null);

        ActionListener a1 = new actionListener();
        Icon icon1 = new ImageIcon(homePage.class.getResource("/resources/account1.png"));
        profileMng_btn = new JButton();
        profileMng_btn.setIcon(icon1);
        profileMng_btn.setFont(new Font("Tahoma", Font.BOLD, 15));
        profileMng_btn.setBounds(82, 25, 220, 81);
        profileMng_btn.setBackground(new Color(210, 255, 147));
        panel.add(profileMng_btn);
        profileMng_btn.addActionListener(a1);

        salesMang_btn = new JButton("sales management");
        salesMang_btn.setFont(new Font("Tahoma", Font.BOLD, 15));
        salesMang_btn.setBounds(413, 25, 220, 81);
        salesMang_btn.setBackground(new Color(210, 255, 147));
        salesMang_btn.addActionListener(a1);
        panel.add(salesMang_btn);

        staffMang_btn = new JButton("staff management");
        staffMang_btn.setForeground(new Color(0, 0, 0));
        staffMang_btn.setBackground(new Color(210, 255, 147));
        staffMang_btn.setFont(new Font("Tahoma", Font.BOLD, 15));
        staffMang_btn.setBounds(82, 166, 220, 81);
        staffMang_btn.addActionListener(a1);
        panel.add(staffMang_btn);

        servicesMang_btn = new JButton("services management");
        servicesMang_btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        servicesMang_btn.setBounds(413, 166, 220, 81);
        servicesMang_btn.setBackground(new Color(210, 255, 147));
        servicesMang_btn.addActionListener(a1);
        panel.add(servicesMang_btn);

        productsMang_btn = new JButton("products management");
        productsMang_btn.setFont(new Font("Tahoma", Font.BOLD, 15));
        productsMang_btn.setBackground(new Color(210, 255, 147));
        productsMang_btn.setBounds(268, 318, 220, 81);
        productsMang_btn.addActionListener(a1);
        panel.add(productsMang_btn);

        signOut_btn = new JButton("sign out");
        signOut_btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        signOut_btn.setBounds(641, 401, 101, 49);
        signOut_btn.setBackground(new Color(224, 34, 41));
        signOut_btn.setForeground(Color.white);
        signOut_btn.addActionListener(a1);
        panel.add(signOut_btn);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(profileMng_btn)) {
                dispose();
                profile_managemnt p1 = new profile_managemnt();
                p1.setVisible(true);
            }
            else if (a.getSource().equals(staffMang_btn))
            {
                employees_management e1=new employees_management();
                e1.setVisible(true);
                dispose();
            }
            else if (a.getSource().equals(servicesMang_btn)){
                services_management s1=new services_management();
                s1.setVisible(true);
                dispose();

            }
            else if (a.getSource().equals(salesMang_btn))
            {
                sales_management s1=new sales_management();
                dispose();
                s1.setVisible(true);
            }
            else if (a.getSource().equals(productsMang_btn))
            {
                products_management p1=new products_management();
                p1.setVisible(true);
                dispose();
            }
            else if (a.getSource().equals(signOut_btn))
            {
                signin s1=new signin();
                s1.setVisible(true);
                dispose();
            }

        }

    }
}
