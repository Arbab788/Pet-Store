package windows;

import backend.address;
import backend.customers;
import backend.location;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_customer extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_btn;
    private JLabel locationID_lbl_;
    private JLabel customer_id_lbl;
    private JTextField customerIDtextField;
    private JLabel customerID_ERRor_lbl;
    private JLabel customer_firstname_lbl;
    private JTextField firstnametextField_1;
    private JLabel FirstName_ERRor_lbl;
    private JLabel customer_Lastname_lbl;
    private JTextField lastnametextField_2;
    private JLabel LASTNAME_ERRor_lbl;
    private JLabel AddressID_ERRor_lbl;
    private JTextField address_IDtextField_3;
    private JLabel address_id_lbl;
    private JLabel houseno_lbl;
    private JLabel streetno_lbl;
    private JTextField locationIDtextField_4;
    private JTextField streetNo_textField_5;
    private JLabel streetNo_ERRor_lbl;
    private JLabel houseNo_ERRor_lbl;
    private JTextField House_no_textField_6;
    private JLabel LocationID_ERRor_lbl;
    private JLabel locationNAME_lbl;
    private JTextField locationName_textField_7;
    private JLabel LocationNAME_ERRor_lbl_1;
    private JLabel zipcode_ERRor_lbl_1;
    private JTextField zip_codetextField_8;
    private JLabel ZIPCODE_lbl;
    private JLabel useradded_msg_lbl;

    public add_customer() {
        initialize();


    }
    private void initialize(){
        ActionListener a1=new actionListener();
        setBounds(100, 100, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_btn = new JButton("ADD");
        add_btn.setBackground(Color.GRAY);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setForeground(Color.WHITE);
        add_btn.setBounds(165, 415, 133, 35);
        panel.add(add_btn);

        locationID_lbl_ = new JLabel("Location ID");
        locationID_lbl_.setFont(new Font("Tahoma", Font.BOLD, 13));
        locationID_lbl_.setBounds(10, 272, 119, 27);
        panel.add(locationID_lbl_);


        customer_id_lbl = new JLabel("Customer ID");
        customer_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        customer_id_lbl.setBounds(10, 37, 119, 27);
        panel.add(customer_id_lbl);

        customerIDtextField = new JTextField();
        customerIDtextField.setColumns(10);
        customerIDtextField.setBounds(139, 38, 184, 27);
        panel.add(customerIDtextField);

        customerID_ERRor_lbl = new JLabel("DIGITS ONLY(MAX 37)");
        customerID_ERRor_lbl.setForeground(Color.RED);
        customerID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        customerID_ERRor_lbl.setBounds(383, 37, 199, 27);
        panel.add(customerID_ERRor_lbl);

        customer_firstname_lbl = new JLabel("First Name");
        customer_firstname_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        customer_firstname_lbl.setBounds(10, 79, 119, 27);
        panel.add(customer_firstname_lbl);

        firstnametextField_1 = new JTextField();
        firstnametextField_1.setColumns(10);
        firstnametextField_1.setBounds(139, 80, 184, 27);
        panel.add(firstnametextField_1);

        FirstName_ERRor_lbl = new JLabel("ALPHABETS ONLY");
        FirstName_ERRor_lbl.setForeground(Color.RED);
        FirstName_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        FirstName_ERRor_lbl.setBounds(383, 79, 199, 27);
        panel.add(FirstName_ERRor_lbl);

        customer_Lastname_lbl = new JLabel("Last Name");
        customer_Lastname_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        customer_Lastname_lbl.setBounds(10, 117, 119, 27);
        panel.add(customer_Lastname_lbl);

        lastnametextField_2 = new JTextField();
        lastnametextField_2.setColumns(10);
        lastnametextField_2.setBounds(139, 118, 184, 27);
        panel.add(lastnametextField_2);

        LASTNAME_ERRor_lbl = new JLabel("ALPHABETS ONLY");
        LASTNAME_ERRor_lbl.setForeground(Color.RED);
        LASTNAME_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        LASTNAME_ERRor_lbl.setBounds(383, 117, 199, 27);
        panel.add(LASTNAME_ERRor_lbl);

        AddressID_ERRor_lbl = new JLabel("DIGITS ONLY(MAX 37)");
        AddressID_ERRor_lbl.setForeground(Color.RED);
        AddressID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        AddressID_ERRor_lbl.setBounds(383, 155, 199, 27);
        panel.add(AddressID_ERRor_lbl);

        address_IDtextField_3 = new JTextField();
        address_IDtextField_3.setColumns(10);
        address_IDtextField_3.setBounds(139, 156, 184, 27);
        panel.add(address_IDtextField_3);

        address_id_lbl = new JLabel("Address ID");
        address_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        address_id_lbl.setBounds(10, 155, 119, 27);
        panel.add(address_id_lbl);

        houseno_lbl = new JLabel("Hosue No.");
        houseno_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        houseno_lbl.setBounds(10, 193, 119, 27);
        panel.add(houseno_lbl);

        streetno_lbl = new JLabel("Street No.");
        streetno_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        streetno_lbl.setBounds(10, 234, 119, 27);
        panel.add(streetno_lbl);

        locationIDtextField_4 = new JTextField();
        locationIDtextField_4.setColumns(10);
        locationIDtextField_4.setBounds(139, 273, 184, 27);
        panel.add(locationIDtextField_4);

        streetNo_textField_5 = new JTextField();
        streetNo_textField_5.setColumns(10);
        streetNo_textField_5.setBounds(139, 235, 184, 27);
        panel.add(streetNo_textField_5);

        streetNo_ERRor_lbl = new JLabel("DIGITS ONLY(MAX 37)");
        streetNo_ERRor_lbl.setForeground(Color.RED);
        streetNo_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        streetNo_ERRor_lbl.setBounds(383, 234, 199, 27);
        panel.add(streetNo_ERRor_lbl);

        houseNo_ERRor_lbl = new JLabel("DIGITS ONLY(MAX 37)");
        houseNo_ERRor_lbl.setForeground(Color.RED);
        houseNo_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        houseNo_ERRor_lbl.setBounds(383, 193, 199, 27);
        panel.add(houseNo_ERRor_lbl);

        House_no_textField_6 = new JTextField();
        House_no_textField_6.setColumns(10);
        House_no_textField_6.setBounds(139, 194, 184, 27);
        panel.add(House_no_textField_6);

        LocationID_ERRor_lbl = new JLabel("DIGITS ONLY(MAX 37)");
        LocationID_ERRor_lbl.setForeground(Color.RED);
        LocationID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        LocationID_ERRor_lbl.setBounds(383, 272, 199, 27);
        panel.add(LocationID_ERRor_lbl);

        locationNAME_lbl = new JLabel("Location Name");
        locationNAME_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        locationNAME_lbl.setBounds(10, 310, 119, 27);
        panel.add(locationNAME_lbl);

        locationName_textField_7 = new JTextField();
        locationName_textField_7.setColumns(10);
        locationName_textField_7.setBounds(139, 311, 184, 27);
        panel.add(locationName_textField_7);

        LocationNAME_ERRor_lbl_1 = new JLabel("ALPHABETS ONLY");
        LocationNAME_ERRor_lbl_1.setForeground(Color.RED);
        LocationNAME_ERRor_lbl_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        LocationNAME_ERRor_lbl_1.setBounds(383, 310, 199, 27);
        panel.add(LocationNAME_ERRor_lbl_1);

        zipcode_ERRor_lbl_1 = new JLabel("DIGITS ONLY(MAX 37)");
        zipcode_ERRor_lbl_1.setForeground(Color.RED);
        zipcode_ERRor_lbl_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        zipcode_ERRor_lbl_1.setBounds(383, 348, 199, 27);
        panel.add(zipcode_ERRor_lbl_1);

        zip_codetextField_8 = new JTextField();
        zip_codetextField_8.setColumns(10);
        zip_codetextField_8.setBounds(139, 349, 184, 27);
        panel.add(zip_codetextField_8);

        ZIPCODE_lbl = new JLabel("Zip Code");
        ZIPCODE_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        ZIPCODE_lbl.setBounds(10, 348, 119, 27);
        panel.add(ZIPCODE_lbl);

        useradded_msg_lbl = new JLabel("User added");
        useradded_msg_lbl.setVerifyInputWhenFocusTarget(false);
        useradded_msg_lbl.setForeground(Color.RED);
        useradded_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        useradded_msg_lbl.setBounds(193, 386, 199, 27);
        panel.add(useradded_msg_lbl);

        customerIDtextField.setText(customers.generatedCustomerId());
        customerIDtextField.setEditable(false);

        customerID_ERRor_lbl.setVisible(false);
        FirstName_ERRor_lbl.setVisible(false);
        LASTNAME_ERRor_lbl.setVisible(false);
        AddressID_ERRor_lbl.setVisible(false);
        houseNo_ERRor_lbl.setVisible(false);
        streetNo_ERRor_lbl.setVisible(false);
        LocationID_ERRor_lbl.setVisible(false);
        LASTNAME_ERRor_lbl.setVisible(false);
        zipcode_ERRor_lbl_1.setVisible(false);
        useradded_msg_lbl.setVisible(false);
        add_btn.addActionListener(a1);


    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn))
            {
//                if (!customers.isdigitOnly(customerIDtextField.getText()))
//                {
//                    customerID_ERRor_lbl.setVisible(true);
//                }
                boolean valid=true;

                if (!customers.isStringOnlyAlphabet(firstnametextField_1.getText()))
                {
                    FirstName_ERRor_lbl.setVisible(true);
                    valid=false;
                }
                if (!customers.isStringOnlyAlphabet(lastnametextField_2.getText()))
                {
                    LASTNAME_ERRor_lbl.setVisible(true);
                    valid=false;
                }
                if (!customers.isStringOnlyAlphabet(locationName_textField_7.getText()))
                {
                    LocationNAME_ERRor_lbl_1.setVisible(true);
                    valid=false;
                }
                if (!customers.isdigitOnly(address_IDtextField_3.getText()))
                {
//                    System.out.println("adrees id error");
                    AddressID_ERRor_lbl.setVisible(true);
                    valid=false;
                }
                if (!customers.isdigitOnly(House_no_textField_6.getText()))
                {
//                    System.out.println("houseno erer");
                    houseNo_ERRor_lbl.setVisible(true);
                    valid=false;
                }
                if ((!customers.isdigitOnly(streetNo_textField_5.getText())))
                {
//                    System.out.println("strretno error");
                    streetNo_ERRor_lbl.setVisible(true);
                    valid=false;
                }
                if (!customers.isdigitOnly(locationIDtextField_4.getText()))
                {
//                    System.out.println("location no");
                    LocationID_ERRor_lbl.setVisible(true);
                    valid=false;
                }
                if (!customers.isStringOnlyAlphabet(locationName_textField_7.getText()))

                {
                    LocationNAME_ERRor_lbl_1.setVisible(true);
                    valid=false;
                }
                if(!customers.isdigitOnly(zip_codetextField_8.getText()))
                {
                    zipcode_ERRor_lbl_1.setVisible(true);
                    valid=false;
                }
                if (!(customerIDtextField.getText().length()<38 && locationIDtextField_4.getText().length()<38 && address_IDtextField_3.getText().length()<38))
                {
                    valid=false;
                    LocationID_ERRor_lbl.setVisible(true);
                    AddressID_ERRor_lbl.setVisible(true);
//                    System.out.println("lengh casddhaksd");
                }

                if (!valid);
                else
                {
                    boolean insert=true;
                    boolean locinsert=true;
                    boolean addressinsert=true;
//                    System.out.println("inside else here");

                    if (!location.newLocation(locationIDtextField_4.getText()))
                    {
                        locationName_textField_7.setText(location.locationName(locationIDtextField_4.getText()));
                        zip_codetextField_8.setText(location.location_zipcode(locationIDtextField_4.getText()));
                        locinsert=false;
                    }
                    if (!address.uniqueaddress(address_IDtextField_3.getText()))
                    {
                        addressinsert=false;
                        House_no_textField_6.setText(address.address_HouseNo(address_IDtextField_3.getText()));
                        streetNo_textField_5.setText(address.address_streetNo(address_IDtextField_3.getText()));

                    }
                    if (locinsert)
                    {
                        location.addLocation(locationIDtextField_4.getText(),locationName_textField_7.getText(),
                                zip_codetextField_8.getText());
                    }
                    if (addressinsert)
                    {
                        address.add_new_address(address_IDtextField_3.getText(),House_no_textField_6.getText(),
                                streetNo_textField_5.getText(),locationIDtextField_4.getText());
                    }
                    if (insert)
                    {
                        customers.addnewcustomer(customerIDtextField.getText(),firstnametextField_1.getText(),
                                lastnametextField_2.getText(),address_IDtextField_3.getText());
                        JOptionPane.showMessageDialog(null,"added");
                        setVisible(false);
                    }

//                    useradded_msg_lbl.setVisible(true);

                }

            }

        }
    }
}