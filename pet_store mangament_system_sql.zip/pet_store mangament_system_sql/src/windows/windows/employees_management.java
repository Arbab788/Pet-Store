package windows;

import backend.employees;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class employees_management extends JFrame {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_employee_btn;
    private JButton view_employee_btn;
    private JButton deleteemployee_btn;
    private JTextArea textFiled;
    private JScrollPane scroll;
    private JButton homepage_btn;
    private JButton update_employee_btn_;


    public employees_management() {
        initialize();
    }
    private void initialize(){
        ActionListener a1=new actionListener();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 150, 800, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 784, 461);
        contentPane.add(panel);
        panel.setLayout(null);

        add_employee_btn = new JButton("ADD EMPLOYEES");
        add_employee_btn.setForeground(new Color(0, 0, 0));
        add_employee_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_employee_btn.setBackground(SystemColor.info);
        add_employee_btn.setBounds(29, 25, 187, 42);
        panel.add(add_employee_btn);
        add_employee_btn.addActionListener(a1);

        view_employee_btn = new JButton("VIEW EMPLOYEES");
        view_employee_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        view_employee_btn.setBackground(SystemColor.info);
        view_employee_btn.addActionListener(a1);

        view_employee_btn.setBounds(288, 25, 181, 42);
        panel.add(view_employee_btn);

        deleteemployee_btn = new JButton("DELETE EMPLOYEES");
        deleteemployee_btn.setBackground(SystemColor.info);
        deleteemployee_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        deleteemployee_btn.setBounds(545, 25, 187, 42);
        panel.add(deleteemployee_btn);
        deleteemployee_btn.addActionListener(a1);

//        textFiled = new JTextArea();
//        textFiled.setWrapStyleWord(true);
//        textFiled.setBounds(141, 238, 561, 83);

//        panel.add(textFiled);
        scroll = new JScrollPane();
        scroll.setBounds(29, 128, 703, 322);
        scroll.setVisible(true);
        panel.add(scroll);

        homepage_btn = new JButton("homePage");
        homepage_btn.setBackground(SystemColor.info);
        homepage_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        homepage_btn.setBounds(29, 89, 132, 33);
        panel.add(homepage_btn);
        homepage_btn.addActionListener(a1);

        update_employee_btn_ = new JButton("UPDATE EMPLOYEES");
        update_employee_btn_.setFont(new Font("Tahoma", Font.BOLD, 13));
        update_employee_btn_.setBackground(SystemColor.info);
        update_employee_btn_.setBounds(288, 78, 181, 42);
        panel.add(update_employee_btn_);
        update_employee_btn_.addActionListener(a1);

    }
    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_employee_btn))
            {
                add_employees_panel e1=new add_employees_panel();
                e1.setVisible(true);

            }
            else if (a.getSource().equals(view_employee_btn))
            {

                try {
                    Connection connection;
                    connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "zatu", "orcl");
                    PreparedStatement queryStatement = connection.prepareStatement("select * " +
                            "from employees");
                    ResultSet rs = queryStatement.executeQuery();
                    JTable table = new JTable();
                    table.setModel(new DefaultTableModel(
                            new Object[][] {
                            },
                            new String[] {
                                    "EMPLOYEE_ID ", "FIRST_NAME","LAST_NAME","SALARY","JOB_TYPE","PHONE#"
                            }
                    ) {
                        Class[] columnTypes = new Class[] {
                                String.class, String.class,String.class,String.class,String.class,String.class
                        };
                        public Class getColumnClass(int columnIndex) {
                            return columnTypes[columnIndex];
                        }
                        boolean[] columnEditables = new boolean[] {
                                false, false,false,false,false,false
                        };
                        public boolean isCellEditable(int row, int column) {
                            return columnEditables[column];
                        }
                    });
                    scroll.setViewportView(table);
                    DefaultTableModel tbModel=(DefaultTableModel) table.getModel();

                    while (rs.next()) {
                        String tbData[]={rs.getString(1),rs.getString(2),rs.getString(3),
                        rs.getString(4),rs.getString(5),rs.getString(6)};
                        tbModel.addRow(tbData);

                    }

                } catch (Exception e) {
                    System.out.println(e);
                }

            }
            else if (a.getSource().equals(deleteemployee_btn))
            {
                String emp_id = JOptionPane.showInputDialog("enter employee id you want to delete");
                if (employees.searchemployee(emp_id))
                {
                    employees.delete_emplyee_record(emp_id);
                    JOptionPane.showMessageDialog(null, "deleted successfully");
                }
                else
                    JOptionPane.showMessageDialog(null,"no such employee found");
            }
            else if (a.getSource().equals(update_employee_btn_))
            {
                String emp_id = JOptionPane.showInputDialog("enter employee id you want to update");
                if (employees.searchemployee(emp_id))
                {
                    update_employees_panel e=new update_employees_panel(emp_id);
                    e.setVisible(true);
                }
                else
                    JOptionPane.showMessageDialog(null,"no such employee found");
            }
            else if (a.getSource().equals(homepage_btn))
            {
                homePage h1=new homePage();
                h1.setVisible(true);
                dispose();

            }


        }
    }

}

