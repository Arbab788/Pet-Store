package windows;


import backend.customers;
import backend.employees;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class add_employees_panel extends JDialog {

    private JPanel contentPane;
    private JPanel panel;
    private JButton add_btn;
    private JLabel employee_id_lbl;
    private JTextField employeeIDtextField;
    private JLabel employeeID_ERRor_lbl;
    private JLabel employee_firstname_lbl;
    private JTextField firstnametextField_1;
    private JLabel FirstName_ERRor_lbl;
    private JLabel employee_Lastname_lbl;
    private JTextField lastnametextField_2;
    private JLabel LASTNAME_ERRor_lbl;
    private JLabel salary_ERRor_lbl;
    private JTextField salary_textField_3;
    private JLabel salary_lbl;
    private JLabel jobType_lbl;
    private JLabel phone_no_lbl;
    private JTextField phoneNo_textField_5;
    private JLabel phoneNo_ERRor_lbl;
    private JLabel employee_added_msg_lbl;
    private JComboBox comboBox;

    public add_employees_panel() {
        initialize();
    }

    private void initialize() {
        ActionListener a1 = new actionListener();
        setBounds(100, 100, 560, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        panel = new JPanel();
        panel.setBackground(SystemColor.activeCaption);
        panel.setBounds(0, 0, 544, 361);
        contentPane.add(panel);
        panel.setLayout(null);

        add_btn = new JButton("ADD");
        add_btn.setBackground(Color.GRAY);
        add_btn.setFont(new Font("Tahoma", Font.BOLD, 13));
        add_btn.setForeground(Color.WHITE);
        add_btn.setBounds(166, 311, 133, 35);
        panel.add(add_btn);
        add_btn.addActionListener(a1);

        employee_id_lbl = new JLabel("Employee ID");
        employee_id_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        employee_id_lbl.setBounds(10, 37, 119, 27);
        panel.add(employee_id_lbl);

        employeeIDtextField = new JTextField();
        employeeIDtextField.setColumns(10);
        employeeIDtextField.setBounds(139, 38, 184, 27);
        panel.add(employeeIDtextField);

        employeeID_ERRor_lbl = new JLabel("DIGITS ONLY");
        employeeID_ERRor_lbl.setForeground(Color.RED);
        employeeID_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        employeeID_ERRor_lbl.setBounds(383, 37, 199, 27);
        panel.add(employeeID_ERRor_lbl);

        employee_firstname_lbl = new JLabel("First Name");
        employee_firstname_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        employee_firstname_lbl.setBounds(10, 79, 119, 27);
        panel.add(employee_firstname_lbl);

        firstnametextField_1 = new JTextField();
        firstnametextField_1.setColumns(10);
        firstnametextField_1.setBounds(139, 80, 184, 27);
        panel.add(firstnametextField_1);

        FirstName_ERRor_lbl = new JLabel("ALPHABETS ONLY");
        FirstName_ERRor_lbl.setForeground(Color.RED);
        FirstName_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        FirstName_ERRor_lbl.setBounds(383, 79, 199, 27);
        panel.add(FirstName_ERRor_lbl);

        employee_Lastname_lbl = new JLabel("Last Name");
        employee_Lastname_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        employee_Lastname_lbl.setBounds(10, 117, 119, 27);
        panel.add(employee_Lastname_lbl);

        lastnametextField_2 = new JTextField();
        lastnametextField_2.setColumns(10);
        lastnametextField_2.setBounds(139, 118, 184, 27);
        panel.add(lastnametextField_2);

        LASTNAME_ERRor_lbl = new JLabel("ALPHABETS ONLY");
        LASTNAME_ERRor_lbl.setForeground(Color.RED);
        LASTNAME_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        LASTNAME_ERRor_lbl.setBounds(383, 117, 199, 27);
        panel.add(LASTNAME_ERRor_lbl);

        salary_ERRor_lbl = new JLabel("DIGITS ONLY");
        salary_ERRor_lbl.setForeground(Color.RED);
        salary_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        salary_ERRor_lbl.setBounds(383, 155, 199, 27);
        panel.add(salary_ERRor_lbl);

        salary_textField_3 = new JTextField();
        salary_textField_3.setColumns(10);
        salary_textField_3.setBounds(139, 156, 184, 27);
        panel.add(salary_textField_3);

        salary_lbl = new JLabel("Salary");
        salary_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        salary_lbl.setBounds(10, 155, 119, 27);
        panel.add(salary_lbl);

        jobType_lbl = new JLabel("Job Type");
        jobType_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        jobType_lbl.setBounds(10, 193, 119, 27);
        panel.add(jobType_lbl);

        phone_no_lbl = new JLabel("Phone No.");
        phone_no_lbl.setFont(new Font("Tahoma", Font.BOLD, 13));
        phone_no_lbl.setBounds(10, 231, 119, 27);
        panel.add(phone_no_lbl);

        phoneNo_textField_5 = new JTextField();
        phoneNo_textField_5.setColumns(10);
        phoneNo_textField_5.setBounds(139, 235, 184, 27);
        panel.add(phoneNo_textField_5);

        phoneNo_ERRor_lbl = new JLabel("DIGITS ONLY");
        phoneNo_ERRor_lbl.setForeground(Color.RED);
        phoneNo_ERRor_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        phoneNo_ERRor_lbl.setBounds(383, 234, 199, 27);
        panel.add(phoneNo_ERRor_lbl);

        employee_added_msg_lbl = new JLabel("Employee Added");
        employee_added_msg_lbl.setVerifyInputWhenFocusTarget(false);
        employee_added_msg_lbl.setForeground(Color.RED);
        employee_added_msg_lbl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
        employee_added_msg_lbl.setBounds(182, 273, 199, 27);
        panel.add(employee_added_msg_lbl);

        String s1[] = {"manager", "saleman", "cashier"};
        comboBox = new JComboBox(s1);
        comboBox.setFont(new Font("Tahoma", Font.BOLD, 13));
        comboBox.setBounds(139, 196, 184, 27);
        panel.add(comboBox);

        phoneNo_ERRor_lbl.setVisible(false);
        FirstName_ERRor_lbl.setVisible(false);
        LASTNAME_ERRor_lbl.setVisible(false);
        salary_ERRor_lbl.setVisible(false);
        employee_added_msg_lbl.setVisible(false);
        employeeID_ERRor_lbl.setVisible(false);

        employeeIDtextField.setText(employees.generateEmployeeID());
        employeeIDtextField.setEditable(false);

    }

    class actionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent a) {
            if (a.getSource().equals(add_btn)) {
//                employee_added_msg_lbl.setVisible(true);
                boolean valid = true;
                if (!customers.isStringOnlyAlphabet(firstnametextField_1.getText())) {
                    FirstName_ERRor_lbl.setVisible(true);
                    valid = false;
                    System.out.println("firstname error");
                }
                if (!customers.isStringOnlyAlphabet(lastnametextField_2.getText())) {
                    LASTNAME_ERRor_lbl.setVisible(true);
                    valid = false;
                    System.out.println("last name error");
                }
                if (!customers.isdigitOnly(salary_textField_3.getText())) {
                    salary_ERRor_lbl.setVisible(true);
                    valid = false;
                    System.out.println("salary error");
                }
                if (!customers.isdigitOnly(phoneNo_textField_5.getText())) {
                    valid = false;
                    phoneNo_ERRor_lbl.setText("11 digits only");
                    phoneNo_ERRor_lbl.setVisible(true);
                }
                if (!(phoneNo_textField_5.getText().length() == 11)) {
                    valid = false;
                    phoneNo_ERRor_lbl.setText("11-digits only");
                    phoneNo_ERRor_lbl.setVisible(true);
                }
                if (!valid) ;
                else {
                    employees.add_employees(employeeIDtextField.getText(), firstnametextField_1.getText(),
                            lastnametextField_2.getText(), salary_textField_3.getText(), String.valueOf(comboBox.getSelectedItem()),
                            phoneNo_textField_5.getText());
                    setVisible(false);
                    JOptionPane.showMessageDialog(null, "inserted");
                    new add_employees_panel().setVisible(true);


                }

            }


        }
    }
}
